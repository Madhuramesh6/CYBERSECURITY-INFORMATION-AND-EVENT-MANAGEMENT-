import axios from "axios";

const API_BASE_URL = "http://localhost:12440"; // Update with your backend URL

// Function to fetch all alerts
export const fetchAlerts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/alerts`, {
      headers: authHeaders(),
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching alerts:", error);
    return [];
  }
};

// Function to filter alerts based on parameters (severity, date, etc.)
export const filterAlerts = async (filters) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/alerts`, {
      params: filters, // Example: { severity: "critical", date: "2025-03-12" }
      headers: authHeaders(),
    });
    return response.data;
  } catch (error) {
    console.error("Error filtering alerts:", error);
    return [];
  }
};

// Function to create a new alert
export const createAlert = async (alertData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/api/alerts`, alertData, {
      headers: { 
        ...authHeaders(), 
        "Content-Type": "application/json" 
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error creating alert:", error);
    return null;
  }
};

// Helper function to add authentication headers
const authHeaders = () => {
  const token = localStorage.getItem("jwt_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
};
