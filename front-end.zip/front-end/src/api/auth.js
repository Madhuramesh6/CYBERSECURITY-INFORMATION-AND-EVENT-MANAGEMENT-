import axios from "axios";

const API_BASE_URL = "http://localhost:12440"; // Change to backend URL in production

// Function to login and get JWT token
export const login = async (username, password) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/token`, 
      new URLSearchParams({ username, password }),
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    );

    const token = response.data.access_token;
    localStorage.setItem("jwt_token", token); // Store token in localStorage
    return token;
  } catch (error) {
    console.error("Login failed:", error);
    return null;
  }
};

// Function to check if user is authenticated
export const isAuthenticated = () => {
  const token = localStorage.getItem("jwt_token");
  return !!token;
};

// Function to logout (remove token)
export const logout = () => {
  localStorage.removeItem("jwt_token");
};

// Function to make authenticated API requests
export const apiRequest = async (endpoint, method = "GET", data = null) => {
  const token = localStorage.getItem("jwt_token");

  if (!token) {
    console.error("User is not authenticated");
    return null;
  }

  try {
    const response = await axios({
      url: `${API_BASE_URL}${endpoint}`,
      method,
      data,
      headers: { Authorization: `Bearer ${token}` },
    });

    return response.data;
  } catch (error) {
    console.error("API Request failed:", error);
    return null;
  }
};
