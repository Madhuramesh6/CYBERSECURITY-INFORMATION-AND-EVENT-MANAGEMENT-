import AWS from 'aws-sdk';
import { cache } from '../utils/cache';
import { normalizeIndicator } from '../utils/threatUtils';

// Initialize AWS services
const s3 = new AWS.S3();
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Configuration
const THREAT_FEEDS = {
  ABUSE_CH: {
    url: 'https://feeds.abuse.ch/ransomware_IP.txt',
    type: 'IP',
    refreshInterval: 3600 // 1 hour
  },
  AWS_IP_RANGES: {
    url: 'https://ip-ranges.amazonaws.com/ip-ranges.json',
    type: 'CIDR',
    refreshInterval: 86400 // 24 hours
  }
};

/**
 * Fetch and process threat intelligence feeds
 * @returns {Promise<Array>} Normalized threat indicators
 */
export const fetchThreatFeeds = async () => {
  try {
    const cachedResults = cache.get('threatIntel');
    if (cachedResults) return cachedResults;

    const results = await Promise.all(
      Object.values(THREAT_FEEDS).map(async feed => {
        const response = await fetch(feed.url);
        if (!response.ok) throw new Error(`Feed fetch failed: ${feed.url}`);
        
        const data = await response.text();
        return processFeedData(data, feed.type);
      })
    );

    const normalized = results.flat().map(normalizeIndicator);
    cache.set('threatIntel', normalized, { ttl: 1800 }); // Cache for 30 mins
    return normalized;
  } catch (error) {
    console.error('Threat intel fetch error:', error);
    throw new Error('Failed to update threat feeds');
  }
};

/**
 * Process raw feed data into structured indicators
 */
const processFeedData = (rawData, type) => {
  switch (type) {
    case 'IP':
      return rawData.split('\n')
        .filter(line => !line.startsWith('#'))
        .map(ip => ({ indicator: ip.trim(), type: 'ipv4' }));
    
    case 'CIDR':
      return JSON.parse(rawData).prefixes
        .map(({ ip_prefix }) => ({ 
          indicator: ip_prefix, 
          type: 'cidr' 
        }));
        
    default:
      return [];
  }
};

/**
 * Check if log entry matches known threats
 * @param {Object} logEntry - AWS log entry (CloudTrail/VPC)
 * @returns {Object} Threat match result
 */
export const analyzeForThreats = async (logEntry) => {
  const threats = await fetchThreatFeeds();
  const indicators = extractIndicators(logEntry);

  const matches = threats.filter(threat => 
    indicators.some(indicator => 
      isIndicatorMatch(indicator, threat)
    )
  );

  return {
    isThreat: matches.length > 0,
    matchedIndicators: matches,
    logEntryId: logEntry.eventID
  };
};

// Helper: Extract IOCs from log entry
const extractIndicators = (log) => {
  const indicators = [];
  
  // Check source IP
  if (log.sourceIPAddress) {
    indicators.push({
      type: 'ipv4',
      value: log.sourceIPAddress
    });
  }
  
  // Check for malicious domains
  if (log.requestParameters?.host) {
    indicators.push({
      type: 'domain',
      value: log.requestParameters.host
    });
  }
  
  return indicators;
};

// Helper: Compare indicators with threat data
const isIndicatorMatch = (indicator, threat) => {
  if (threat.type === 'cidr') {
    return isIPInCIDR(indicator.value, threat.indicator);
  }
  return indicator.value === threat.indicator;
};

// CIDR range check utility
const isIPInCIDR = (ip, cidr) => {
  const [range, bits] = cidr.split('/');
  const mask = (-1 << (32 - bits)) >>> 0;
  return (ipToInt(ip) & mask) === (ipToInt(range) & mask);
};

// IP to integer conversion
const ipToInt = (ip) => 
  ip.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0) >>> 0;

/**
 * Store threat matches in DynamoDB
 */
export const storeThreatMatch = async (matchResult) => {
  const params = {
    TableName: 'ThreatMatches',
    Item: {
      matchId: AWS.util.uuid.v4(),
      timestamp: new Date().toISOString(),
      ...matchResult,
      ttl: Math.floor(Date.now() / 1000) + 604800 // 7-day TTL
    }
  };

  await dynamodb.put(params).promise();
};

/**
 * Get recent threats from S3/DynamoDB
 */
export const getHistoricalThreats = async (days = 7) => {
  const params = {
    TableName: 'ThreatMatches',
    FilterExpression: 'timestamp >= :date',
    ExpressionAttributeValues: {
      ':date': new Date(Date.now() - days * 86400000).toISOString()
    }
  };

  const result = await dynamodb.scan(params).promise();
  return result.Items;
};