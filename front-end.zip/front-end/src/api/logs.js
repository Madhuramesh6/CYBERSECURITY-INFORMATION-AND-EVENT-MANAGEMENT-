import axios from "axios";

const API_BASE_URL = "http://localhost:12440"; // Update with your backend URL

// Function to fetch all logs
export const fetchLogs = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/logs`, {
      headers: authHeaders(),
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching logs:", error);
    return [];
  }
};

// Function to filter logs based on parameters (severity, date, etc.)
export const filterLogs = async (filters) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/logs`, {
      params: filters, // Example: { severity: "high", date: "2025-03-12" }
      headers: authHeaders(),
    });
    return response.data;
  } catch (error) {
    console.error("Error filtering logs:", error);
    return [];
  }
};

// Function to send a new log entry to the backend
export const sendLog = async (logData) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/api/logs`, logData, {
      headers: { 
        ...authHeaders(), 
        "Content-Type": "application/json" 
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error sending log:", error);
    return null;
  }
};

// Helper function to add authentication headers
const authHeaders = () => {
  const token = localStorage.getItem("jwt_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
};
