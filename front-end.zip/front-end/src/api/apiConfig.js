import axios from "axios";
const API = axios.create({
  baseURL: "/api", // Proxy will redirect this to http://localhost:12440
});
export const fetchStatus = async () => {
  try {
    const response = await fetch(`http://localhost:12440/openapi.json`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    console.log("API Response:", data);
    return data;
  } catch (error) {
    console.error("Error fetching status:", error);
    return null;
  }
};
