// src/components/MitreMatrix.js
import mitreData from '../data/attack-patterns.json'; // downloaded from MITRE repo

export default function MitreMatrix({ techniqueIds }) {
  return (
    <div className="grid grid-cols-3 gap-4 p-4">
      {techniqueIds.map(id => {
        const match = mitreData.objects.find(t => t.external_references?.[0]?.external_id === id);
        return (
          <div key={id} className="p-2 bg-gray-800 rounded text-white">
            <h3 className="font-bold">{match?.external_references[0].external_id}</h3>
            <p>{match?.name}</p>
            <p className="text-xs">{match?.description?.slice(0, 100)}...</p>
          </div>
        );
      })}
    </div>
  );
}
