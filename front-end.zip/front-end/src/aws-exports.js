const awsConfig = {
  Auth: {
    region: 'eu-north-1',
    userPoolId: 'eu-north-1_Kq7SlUwMy',
    userPoolWebClientId: '11co4g6n2q4p1266rq2ri7l220',
    identityPoolId: 'eu-north-1:a532e050-0e05-4136-a1df-1b122876e3e6',
    mandatorySignIn: false,
  },
};

export default awsConfig;
