import AWS from "aws-sdk";
import dotenv from "dotenv";

dotenv.config(); // ✅ Ensure environment variables are loaded

// ✅ Load environment variables
const REGION = process.env.AWS_REGION || "eu-north-1";
const USER_POOL_ID = process.env.AWS_COGNITO_USER_POOL_ID;
const CLIENT_ID = process.env.AWS_COGNITO_CLIENT_ID;
const IDENTITY_POOL_ID = process.env.AWS_COGNITO_IDENTITY_POOL_ID;
const KINESIS_STREAM_NAME = process.env.AWS_KINESIS_STREAM_NAME;
const DYNAMODB_TABLE = process.env.AWS_DYNAMODB_TABLE;
const S3_BUCKET = process.env.AWS_S3_BUCKET;

// ✅ Ensure required environment variables are defined
if (!USER_POOL_ID || !CLIENT_ID || !IDENTITY_POOL_ID) {
  console.error("❌ Missing Cognito configuration. Check environment variables.");
  throw new Error("Cognito configuration is missing!");
}

// ✅ Configure AWS SDK globally
AWS.config.update({
  region: REGION,
  credentials: new AWS.CognitoIdentityCredentials({
    IdentityPoolId: IDENTITY_POOL_ID,
  }),
});

// ✅ Cognito Authentication Setup
const cognito = new AWS.CognitoIdentityServiceProvider({
  region: REGION,
});

// ✅ Kinesis for Real-Time Log Streaming
const kinesis = new AWS.Kinesis({
  region: REGION,
});

// ✅ DynamoDB for Structured Log Storage
const dynamoDB = new AWS.DynamoDB.DocumentClient({
  region: REGION,
});

// ✅ S3 for Long-Term Log Storage
const s3 = new AWS.S3({
  region: REGION,
});

/**
 * 🚀 Store security logs in DynamoDB
 * @param {Object} logData - Log data to store
 */
export const storeLogInDynamoDB = async (logData) => {
  if (!DYNAMODB_TABLE) throw new Error("DynamoDB table name is missing!");

  const params = {
    TableName: DYNAMODB_TABLE,
    Item: logData,
  };

  try {
    await dynamoDB.put(params).promise();
    console.log("✅ Log stored in DynamoDB:", logData);
  } catch (error) {
    console.error("❌ DynamoDB Error:", error);
    throw error;
  }
};

/**
 * 🚀 Send logs to AWS Kinesis for real-time processing
 * @param {Object} logData - Log data to send
 */
export const sendLogToKinesis = async (logData) => {
  if (!KINESIS_STREAM_NAME) throw new Error("Kinesis Stream Name is missing!");

  const params = {
    StreamName: KINESIS_STREAM_NAME,
    PartitionKey: logData.id || "default",
    Data: JSON.stringify(logData),
  };

  try {
    await kinesis.putRecord(params).promise();
    console.log("✅ Log sent to Kinesis:", logData);
  } catch (error) {
    console.error("❌ Kinesis Error:", error);
    throw error;
  }
};

/**
 * 🚀 Store security logs in S3 for long-term analysis
 * @param {string} logId - Unique ID for the log file
 * @param {Object} logData - Log data to store
 */
export const storeLogInS3 = async (logId, logData) => {
  if (!S3_BUCKET) throw new Error("S3 Bucket Name is missing!");

  const params = {
    Bucket: S3_BUCKET,
    Key: `logs/${logId}.json`,
    Body: JSON.stringify(logData, null, 2),
    ContentType: "application/json",
  };

  try {
    await s3.putObject(params).promise();
    console.log(`✅ Log stored in S3: ${logId}.json`);
  } catch (error) {
    console.error("❌ S3 Error:", error);
    throw error;
  }
};

/**
 * 🚀 Authenticate User via Cognito
 * @param {string} username - User email/username
 * @param {string} password - User password
 */
export const authenticateUser = async (username, password) => {
  if (!CLIENT_ID) throw new Error("Cognito Client ID is missing!");

  const params = {
    AuthFlow: "USER_PASSWORD_AUTH",
    ClientId: CLIENT_ID,
    AuthParameters: {
      USERNAME: username,
      PASSWORD: password,
    },
  };

  try {
    const result = await cognito.initiateAuth(params).promise();
    console.log("✅ Authentication Success:", result);
    return result.AuthenticationResult;
  } catch (error) {
    console.error("❌ Cognito Authentication Error:", error);
    throw error;
  }
};
