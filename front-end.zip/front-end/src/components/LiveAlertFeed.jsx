{alert.mitre_techniques?.length > 0 && (
  <div className="mt-2">
    <span className="font-medium text-gray-300 text-sm">MITRE Techniques:</span>
    <div className="flex flex-wrap gap-2 mt-1">
      {alert.mitre_techniques.map((tech, idx) => (
        <span
          key={idx}
          className="bg-gray-800 text-blue-300 text-xs px-2 py-1 rounded-xl border border-blue-500"
        >
          {tech}
        </span>
      ))}
    </div>
  </div>
)}
