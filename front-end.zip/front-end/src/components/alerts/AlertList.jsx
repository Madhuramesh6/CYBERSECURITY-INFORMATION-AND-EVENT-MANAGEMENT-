import React from 'react';
import useFetch from '../../hooks/useFetch';

const AlertList = () => {
    const { data: alerts, loading, error } = useFetch('https://api.example.com/alerts');

    if (loading) return <p>Loading alerts...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <div>
            <h2>Alerts</h2>
            <ul>
                {alerts.map(alert => (
                    <li key={alert.id}>
                        <strong>{alert.title}</strong> - {alert.severity}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default AlertList;
