import React, { useState, useEffect, useContext } from 'react';
import { AlertContext } from '../../contexts/AlertContext';
import { useAWS } from '../../hooks/useAWS';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Combobox } from '@headlessui/react';

const AlertFilters = () => {
  const { alerts, setFilteredAlerts } = useContext(AlertContext);
  const { getCloudWatchLogs } = useAWS();
  const [filters, setFilters] = useState({
    severity: '',
    source: '',
    timeRange: { start: null, end: null },
    searchQuery: '',
    awsService: '',
    status: ''
  });

  // Available filter options
  const filterOptions = {
    severities: ['critical', 'high', 'medium', 'low', 'informational'],
    sources: ['AWS GuardDuty', 'CloudTrail', 'VPC Flow', 'Custom Rule'],
    awsServices: ['EC2', 'S3', 'IAM', 'Lambda', 'CloudFront'],
    statuses: ['open', 'investigating', 'resolved', 'false positive']
  };

  // Fetch AWS-specific filter options
  const [awsResources, setAwsResources] = useState([]);
  useEffect(() => {
    const fetchAwsResources = async () => {
      const resources = await getCloudWatchLogs('/aws/resources');
      setAwsResources(resources.map(r => ({
        id: r.arn,
        name: r.resourceName,
        type: r.resourceType
      })));
    };
    fetchAwsResources();
  }, [getCloudWatchLogs]);

  // Apply filters with debounce
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      const filtered = alerts.filter(alert => {
        // Severity filter
        if (filters.severity && alert.severity !== filters.severity) return false;
        
        // Source filter
        if (filters.source && alert.source !== filters.source) return false;
        
        // Time range filter
        if (filters.timeRange.start && new Date(alert.timestamp) < filters.timeRange.start) return false;
        if (filters.timeRange.end && new Date(alert.timestamp) > filters.timeRange.end) return false;
        
        // AWS service filter
        if (filters.awsService && !alert.awsResources?.some(r => r.type === filters.awsService)) return false;
        
        // Status filter
        if (filters.status && alert.status !== filters.status) return false;
        
        // Search query (case-insensitive)
        if (filters.searchQuery) {
          const query = filters.searchQuery.toLowerCase();
          return (
            alert.message.toLowerCase().includes(query) ||
            alert.id.toLowerCase().includes(query) ||
            alert.sourceIp?.toLowerCase().includes(query)
          );
        }
        
        return true;
      });
      
      setFilteredAlerts(filtered);
    }, 300); // 300ms debounce

    return () => clearTimeout(timeoutId);
  }, [filters, alerts, setFilteredAlerts]);

  // Reset all filters
  const handleReset = () => {
    setFilters({
      severity: '',
      source: '',
      timeRange: { start: null, end: null },
      searchQuery: '',
      awsService: '',
      status: ''
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search Input */}
        <div className="col-span-1 md:col-span-2">
          <label htmlFor="search" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Search Alerts
          </label>
          <input
            type="text"
            id="search"
            placeholder="Search by message, ID, or IP..."
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            value={filters.searchQuery}
            onChange={(e) => setFilters({...filters, searchQuery: e.target.value})}
          />
        </div>

        {/* Severity Filter */}
        <div>
          <label htmlFor="severity" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Severity
          </label>
          <select
            id="severity"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            value={filters.severity}
            onChange={(e) => setFilters({...filters, severity: e.target.value})}
          >
            <option value="">All Severities</option>
            {filterOptions.severities.map(severity => (
              <option key={severity} value={severity}>
                {severity.charAt(0).toUpperCase() + severity.slice(1)}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Status
          </label>
          <select
            id="status"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            value={filters.status}
            onChange={(e) => setFilters({...filters, status: e.target.value})}
          >
            <option value="">All Statuses</option>
            {filterOptions.statuses.map(status => (
              <option key={status} value={status}>
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </option>
            ))}
          </select>
        </div>

        {/* Source Filter */}
        <div>
          <label htmlFor="source" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Source
          </label>
          <select
            id="source"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            value={filters.source}
            onChange={(e) => setFilters({...filters, source: e.target.value})}
          >
            <option value="">All Sources</option>
            {filterOptions.sources.map(source => (
              <option key={source} value={source}>
                {source}
              </option>
            ))}
          </select>
        </div>

        {/* AWS Service Filter */}
        <div>
          <label htmlFor="awsService" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            AWS Service
          </label>
          <select
            id="awsService"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            value={filters.awsService}
            onChange={(e) => setFilters({...filters, awsService: e.target.value})}
          >
            <option value="">All Services</option>
            {filterOptions.awsServices.map(service => (
              <option key={service} value={service}>
                {service}
              </option>
            ))}
          </select>
        </div>

        {/* AWS Resource Autocomplete */}
        <div className="col-span-1 md:col-span-2">
          <label htmlFor="awsResource" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            AWS Resource
          </label>
          <Combobox value={filters.awsResource} onChange={(value) => setFilters({...filters, awsResource: value})}>
            <div className="relative">
              <Combobox.Input
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
                displayValue={(resource) => resource?.name || ''}
                placeholder="Search AWS resources..."
              />
              <Combobox.Options className="absolute z-10 mt-1 w-full bg-white dark:bg-gray-700 shadow-lg rounded-md py-1 text-base ring-1 ring-black ring-opacity-5 overflow-auto max-h-60 focus:outline-none">
                {awsResources.map((resource) => (
                  <Combobox.Option
                    key={resource.id}
                    value={resource}
                    className={({ active }) =>
                      `px-4 py-2 ${active ? 'bg-blue-100 dark:bg-blue-900' : 'text-gray-900 dark:text-white'}`
                    }
                  >
                    <div className="flex justify-between">
                      <span>{resource.name}</span>
                      <span className="text-gray-500 dark:text-gray-400">{resource.type}</span>
                    </div>
                  </Combobox.Option>
                ))}
              </Combobox.Options>
            </div>
          </Combobox>
        </div>

        {/* Date Range Picker */}
        <div className="col-span-1 md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Time Range
          </label>
          <div className="flex space-x-2">
            <DatePicker
              selected={filters.timeRange.start}
              onChange={(date) => setFilters({...filters, timeRange: {...filters.timeRange, start: date}})}
              selectsStart
              startDate={filters.timeRange.start}
              endDate={filters.timeRange.end}
              placeholderText="Start date"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
            <DatePicker
              selected={filters.timeRange.end}
              onChange={(date) => setFilters({...filters, timeRange: {...filters.timeRange, end: date}})}
              selectsEnd
              startDate={filters.timeRange.start}
              endDate={filters.timeRange.end}
              minDate={filters.timeRange.start}
              placeholderText="End date"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
        </div>

        {/* Reset Button */}
        <div className="flex items-end">
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white rounded-md hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
          >
            Reset Filters
          </button>
        </div>
      </div>
    </div>
  );
};

export default AlertFilters;