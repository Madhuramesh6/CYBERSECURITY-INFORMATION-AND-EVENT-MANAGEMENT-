import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/AlertCard.css';

const AlertCard = ({ alert }) => {
    return (
        <div className={`alert-card ${alert.severity.toLowerCase()}`}>
            <h3>{alert.title}</h3>
            <p>{alert.description}</p>
            <span className="timestamp">{new Date(alert.timestamp).toLocaleString()}</span>
            <Link to={`/alerts/${alert.id}`} className="details-link">View Details</Link>
        </div>
    );
};

export default AlertCard;
