import React from 'react';
import { useParams } from 'react-router-dom';
import '../../styles/alerts.css';

const AlertDetails = () => {
    const { alertId } = useParams();

    return (
        <div className="alert-details">
            <h2>Alert Details</h2>
            <p>Details for alert ID: {alertId}</p>
            <p>More information about the alert will be displayed here.</p>
        </div>
    );
};

export default AlertDetails;
