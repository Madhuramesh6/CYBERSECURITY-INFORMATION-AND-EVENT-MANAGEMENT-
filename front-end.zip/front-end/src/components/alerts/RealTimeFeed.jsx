import React, { useState, useEffect, useContext } from 'react';
import { AlertContext } from '../../contexts/AlertContext';
import { AnimatePresence, motion } from 'framer-motion';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

const RealTimeFeed = () => {
  const { addAlerts } = useContext(AlertContext);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [latestAlert, setLatestAlert] = useState(null);
  const [streamStats, setStreamStats] = useState({
    throughput: '0',
    recordCount: 0,
    lastUpdated: null
  });

  const alertVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, x: 100 }
  };

  useEffect(() => {
    let socket;

    const connectWebSocket = () => {
      setConnectionStatus('connecting');
      socket = new WebSocket('ws://localhost:5173/?token=cV0cqFIgdMBy'); // or your deployed WebSocket URL

      socket.onopen = () => {
        console.log('WebSocket connected');
        setConnectionStatus('connected');
      };

      socket.onmessage = (event) => {
        try {
          const alertData = JSON.parse(event.data);
          handleNewAlert(alertData);
        } catch (err) {
          console.error('Invalid alert data:', err);
        }
      };

      socket.onerror = (err) => {
        console.error('WebSocket error:', err);
        setConnectionStatus('error');
      };

      socket.onclose = () => {
        console.log('WebSocket closed');
        setConnectionStatus('disconnected');
        setTimeout(connectWebSocket, 5000); // retry
      };
    };

    connectWebSocket();

    const handleNewAlert = (alert) => {
      addAlerts([alert]);
      setLatestAlert(alert);
      setStreamStats((prev) => ({
        ...prev,
        recordCount: prev.recordCount + 1,
        lastUpdated: new Date()
      }));
    };

    return () => {
      if (socket) socket.close();
    };
  }, [addAlerts]);

  const getStatusColor = () => {
    switch (connectionStatus) {
      case 'connected': return 'bg-green-500';
      case 'connecting': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const renderAlertSeverity = (severity) => {
    const colors = {
      critical: 'bg-red-600',
      high: 'bg-orange-500',
      medium: 'bg-yellow-400',
      low: 'bg-blue-400',
      informational: 'bg-gray-400'
    };
    return (
      <span className={`${colors[severity.toLowerCase()] || 'bg-gray-500'} 
        text-white text-xs px-2 py-1 rounded-full`}>
        {severity}
      </span>
    );
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 h-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Real-Time Alert Feed</h3>
        <div className="flex items-center space-x-2">
          <span className={`w-3 h-3 rounded-full ${getStatusColor()}`}></span>
          <span className="text-sm text-gray-600 dark:text-gray-300">{connectionStatus.toUpperCase()}</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-4 text-center">
        <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
          <p className="text-xs text-gray-500 dark:text-gray-400">THROUGHPUT</p>
          <p className="font-mono text-sm">{streamStats.throughput}</p>
        </div>
        <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
          <p className="text-xs text-gray-500 dark:text-gray-400">ALERTS TODAY</p>
          <p className="font-mono text-sm">{streamStats.recordCount}</p>
        </div>
        <div className="bg-gray-100 dark:bg-gray-700 p-2 rounded">
          <p className="text-xs text-gray-500 dark:text-gray-400">LAST EVENT</p>
          <p className="font-mono text-sm">
            {streamStats.lastUpdated ? new Date(streamStats.lastUpdated).toLocaleTimeString() : '--:--:--'}
          </p>
        </div>
      </div>

      <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 h-48 overflow-y-auto">
        <AnimatePresence>
          {latestAlert && (
            <motion.div
              key={latestAlert.id}
              initial="initial"
              animate="animate"
              exit="exit"
              variants={alertVariants}
              transition={{ duration: 0.3 }}
              className="mb-3 last:mb-0"
            >
              <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg border-l-4 border-blue-500">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-gray-800 dark:text-white flex items-center">
                      {latestAlert.title}
                      <span className="ml-2">{renderAlertSeverity(latestAlert.severity)}</span>
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                      {latestAlert.message.substring(0, 100)}...
                    </p>
                  </div>
                  <span
                    className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap"
                    data-tooltip-id="alert-timestamp"
                    data-tooltip-content={new Date(latestAlert.timestamp).toLocaleString()}
                  >
                    {new Date(latestAlert.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {latestAlert.tags?.map(tag => (
                    <span key={tag} className="text-xs px-2 py-0.5 bg-gray-200 dark:bg-gray-600 rounded">{tag}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!latestAlert && (
          <div className="h-full flex items-center justify-center text-gray-400">
            {connectionStatus === 'connected' ? 'Waiting for alerts...' : `Status: ${connectionStatus}`}
          </div>
        )}
      </div>

      <div className="mt-4 flex justify-between items-center">
        <button
          onClick={() => window.location.reload()}
          className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
        >
          {connectionStatus === 'error' ? 'Reconnect' : 'Refresh Connection'}
        </button>
        <span className="text-xs text-gray-500 dark:text-gray-400">
          Source: WebSocket
        </span>
      </div>

      <Tooltip id="alert-timestamp" />
    </div>
  );
};

export default RealTimeFeed;
