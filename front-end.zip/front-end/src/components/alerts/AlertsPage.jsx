import React, { useEffect, useState } from 'react';
import AlertList from '../../components/AlertList';
import { fetchAlerts } from '../../services/alertService';
import '../../styles/alerts.css';

const AlertsPage = () => {
    const [alerts, setAlerts] = useState([]);

    useEffect(() => {
        const getAlerts = async () => {
            const data = await fetchAlerts();
            setAlerts(data);
        };
        getAlerts();
    }, []);

    return (
        <div className="alerts-page">
            <h2>Security Alerts</h2>
            <AlertList alerts={alerts} />
        </div>
    );
};

export default AlertsPage;
