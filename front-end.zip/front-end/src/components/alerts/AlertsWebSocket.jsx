import React, { useEffect, useState } from "react";

const AlertsWebSocket = () => {
  const [messages, setMessages] = useState([]);
  const [ws, setWs] = useState(null);

  useEffect(() => {
    // Connect to your FastAPI WebSocket
    const websocket = new WebSocket("ws://localhost:12440/ws/alerts");

    websocket.onopen = () => {
      console.log("Connected to WebSocket server");
      websocket.send("Hello from React SIEM Dashboard");
    };

    websocket.onmessage = (event) => {
      console.log("Received:", event.data);
      setMessages((prevMessages) => [...prevMessages, event.data]);
    };

    websocket.onclose = () => {
      console.log("WebSocket connection closed");
    };

    websocket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    setWs(websocket);

    // Cleanup on component unmount
    return () => {
      websocket.close();
    };
  }, []);

  const sendTestAlert = () => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send("Manual test alert from frontend");
    }
  };

  return (
    <div className="p-4 bg-white rounded-2xl shadow-xl space-y-4">
      <h2 className="text-xl font-bold">Real-Time Alerts</h2>
      <button
        onClick={sendTestAlert}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
      >
        Send Test Alert
      </button>
      <ul className="space-y-2">
        {messages.map((msg, index) => (
          <li
            key={index}
            className="p-2 border border-gray-300 rounded-lg bg-gray-50"
          >
            {msg}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AlertsWebSocket;
