import React from 'react';
import PropTypes from 'prop-types';
import { 
  Cog6ToothIcon,
  ArrowsPointingOutIcon,
  ChartBarIcon,
  ShieldCheckIcon,
  BoltIcon 
} from '@heroicons/react/24/outline';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

const DashboardCard = ({
  title,
  children,
  icon,
  severity,
  isExpandable = false,
  isConfigurable = false,
  onConfigure,
  onExpand,
  className = '',
  loading = false,
  ...props
}) => {
  // Severity border colors
  const severityBorderColors = {
    critical: 'border-red-500',
    high: 'border-orange-500',
    medium: 'border-yellow-400',
    low: 'border-blue-400',
    informational: 'border-gray-400',
    none: 'border-gray-200 dark:border-gray-600'
  };

  // Default icon based on severity
  const getDefaultIcon = () => {
    switch(severity) {
      case 'critical': return ShieldCheckIcon;
      case 'high': return ShieldCheckIcon;
      case 'medium': return BoltIcon;
      default: return ChartBarIcon;
    }
  };

  const Icon = icon || getDefaultIcon();
  const borderColor = severity ? severityBorderColors[severity] : severityBorderColors.none;

  return (
    <div 
      className={`
        rounded-lg shadow-sm border bg-white dark:bg-gray-800
        transition-all duration-200 hover:shadow-md
        ${borderColor}
        ${className}
      `}
      {...props}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex items-center space-x-2">
          <Icon className="h-5 w-5 text-gray-500 dark:text-gray-400" />
          <h3 className="text-sm font-medium text-gray-900 dark:text-white">
            {title}
          </h3>
          {severity && (
            <span 
              className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                severity === 'critical' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                severity === 'high' ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' :
                severity === 'medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                severity === 'low' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
                'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
              }`}
            >
              {severity.charAt(0).toUpperCase() + severity.slice(1)}
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {isConfigurable && (
            <button
              onClick={onConfigure}
              data-tooltip-id={`${title}-config`}
              data-tooltip-content="Configure widget"
              className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
            >
              <Cog6ToothIcon className="h-4 w-4" />
            </button>
          )}
          
          {isExpandable && (
            <button
              onClick={onExpand}
              data-tooltip-id={`${title}-expand`}
              data-tooltip-content="Expand view"
              className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
            >
              <ArrowsPointingOutIcon className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          children
        )}
      </div>

      {/* Tooltips */}
      {isConfigurable && (
        <Tooltip id={`${title}-config`} className="z-50 text-xs font-medium" />
      )}
      {isExpandable && (
        <Tooltip id={`${title}-expand`} className="z-50 text-xs font-medium" />
      )}
    </div>
  );
};

DashboardCard.propTypes = {
  title: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
  icon: PropTypes.elementType,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']),
  isExpandable: PropTypes.bool,
  isConfigurable: PropTypes.bool,
  onConfigure: PropTypes.func,
  onExpand: PropTypes.func,
  className: PropTypes.string,
  loading: PropTypes.bool,
};

DashboardCard.defaultProps = {
  isExpandable: false,
  isConfigurable: false,
  className: '',
  loading: false,
};

export default DashboardCard;