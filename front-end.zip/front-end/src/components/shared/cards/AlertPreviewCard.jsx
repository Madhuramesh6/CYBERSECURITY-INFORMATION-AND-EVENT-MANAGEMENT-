import React from 'react';
import PropTypes from 'prop-types';
import { 
  ExclamationTriangleIcon,
  ShieldExclamationIcon,
  BoltIcon,
  InformationCircleIcon,
  ArrowTopRightOnSquareIcon,
  ClockIcon
} from '@heroicons/react/24/outline';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';
import SeverityPill from './SeverityPill';
import { formatDistanceToNow } from 'date-fns';

const AlertPreviewCard = ({
  id,
  title,
  description,
  severity = 'medium',
  timestamp,
  source,
  awsResource,
  isNew = false,
  isSelected = false,
  onClick,
  className = '',
  ...props
}) => {
  // Severity icon mapping
  const severityIcons = {
    critical: ExclamationTriangleIcon,
    high: ShieldExclamationIcon,
    medium: BoltIcon,
    low: InformationCircleIcon,
    informational: InformationCircleIcon
  };

  const Icon = severityIcons[severity] || InformationCircleIcon;
  const timeAgo = formatDistanceToNow(new Date(timestamp), { addSuffix: true });

  return (
    <div
      onClick={onClick}
      className={`
        border rounded-lg p-4 transition-all duration-200
        ${isSelected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-600'}
        ${isNew ? 'border-l-4 border-l-red-500' : ''}
        bg-white dark:bg-gray-800
        hover:shadow-md hover:border-gray-300 dark:hover:border-gray-500
        ${onClick ? 'cursor-pointer' : ''}
        ${className}
      `}
      {...props}
    >
      <div className="flex justify-between items-start">
        <div className="flex items-start space-x-3">
          <div className={`pt-0.5 ${isNew ? 'text-red-500' : 'text-gray-400 dark:text-gray-500'}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <h3 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                {title}
              </h3>
              <SeverityPill severity={severity} size="xs" />
            </div>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">
              {description}
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500 dark:text-gray-400">
              {source && (
                <span className="flex items-center">
                  <span className="truncate">Source: {source}</span>
                </span>
              )}
              {awsResource && (
                <span 
                  className="flex items-center"
                  data-tooltip-id={`alert-${id}-resource`}
                  data-tooltip-content={`AWS Resource: ${awsResource.arn}`}
                >
                  <CloudIcon className="h-3 w-3 mr-1" />
                  <span className="truncate max-w-[120px]">{awsResource.type}</span>
                </span>
              )}
              <span className="flex items-center">
                <ClockIcon className="h-3 w-3 mr-1" />
                {timeAgo}
              </span>
            </div>
          </div>
        </div>
        {onClick && (
          <ArrowTopRightOnSquareIcon className="h-4 w-4 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300" />
        )}
      </div>

      {/* Tooltips */}
      {awsResource && (
        <Tooltip 
          id={`alert-${id}-resource`}
          className="z-50 text-xs font-medium max-w-[300px] break-words"
        />
      )}
    </div>
  );
};

AlertPreviewCard.propTypes = {
  id: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']),
  timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.instanceOf(Date)]).isRequired,
  source: PropTypes.string,
  awsResource: PropTypes.shape({
    arn: PropTypes.string,
    type: PropTypes.string
  }),
  isNew: PropTypes.bool,
  isSelected: PropTypes.bool,
  onClick: PropTypes.func,
  className: PropTypes.string,
};

AlertPreviewCard.defaultProps = {
  severity: 'medium',
  isNew: false,
  isSelected: false,
  className: '',
};

export default AlertPreviewCard;