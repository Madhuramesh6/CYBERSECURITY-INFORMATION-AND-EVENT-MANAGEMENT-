import React from 'react';
import PropTypes from 'prop-types';
import { 
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  ShieldCheckIcon,
  ExclamationTriangleIcon,
  LightBulbIcon,
  CloudIcon
} from '@heroicons/react/24/outline';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

const StatCard = ({
  title,
  value,
  trend = 'neutral',
  change,
  timeframe = '24h',
  severity,
  awsService,
  isLoading = false,
  onClick,
  className = '',
  ...props
}) => {
  // Trend configuration
  const trendConfig = {
    up: {
      icon: ArrowTrendingUpIcon,
      color: 'text-green-500',
      bgColor: 'bg-green-50 dark:bg-green-900/30',
      label: 'Increase'
    },
    down: {
      icon: ArrowTrendingDownIcon,
      color: 'text-red-500',
      bgColor: 'bg-red-50 dark:bg-red-900/30',
      label: 'Decrease'
    },
    neutral: {
      icon: null,
      color: 'text-gray-500',
      bgColor: 'bg-gray-50 dark:bg-gray-700',
      label: 'No change'
    }
  };

  // Severity configuration
  const severityConfig = {
    critical: 'border-red-500',
    high: 'border-orange-500',
    medium: 'border-yellow-400',
    low: 'border-blue-400',
    informational: 'border-gray-400',
    none: 'border-transparent'
  };

  // AWS service icons
  const awsServiceIcons = {
    guardduty: ShieldCheckIcon,
    cloudtrail: CloudIcon,
    iam: ExclamationTriangleIcon,
    inspector: LightBulbIcon,
    default: ShieldCheckIcon
  };

  const ServiceIcon = awsService ? awsServiceIcons[awsService.toLowerCase()] || awsServiceIcons.default : null;
  const currentTrend = trendConfig[trend];
  const TrendIcon = currentTrend.icon;

  return (
    <div 
      onClick={onClick}
      className={`
        border-l-4 rounded-lg p-4 shadow-sm transition-all duration-200
        bg-white dark:bg-gray-800 hover:shadow-md
        ${severity ? severityConfig[severity] : 'border-gray-200 dark:border-gray-600'}
        ${onClick ? 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50' : ''}
        ${className}
      `}
      {...props}
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400 flex items-center">
            {awsService && ServiceIcon && (
              <ServiceIcon className="h-4 w-4 mr-2" />
            )}
            {title}
          </p>
          <div className="mt-1 flex items-baseline">
            {isLoading ? (
              <div className="h-8 w-20 bg-gray-200 dark:bg-gray-600 rounded animate-pulse"></div>
            ) : (
              <>
                <p className="text-2xl font-semibold text-gray-900 dark:text-white">
                  {typeof value === 'number' ? value.toLocaleString() : value}
                </p>
                {change && (
                  <span 
                    className={`ml-2 flex items-center text-sm font-medium ${currentTrend.color}`}
                    data-tooltip-id={`statcard-${title}-trend`}
                    data-tooltip-content={`${currentTrend.label} ${change}% compared to previous ${timeframe}`}
                  >
                    {TrendIcon && <TrendIcon className="h-4 w-4 mr-0.5" />}
                    {change}%
                  </span>
                )}
              </>
            )}
          </div>
        </div>
        
        {severity && (
          <span 
            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              severity === 'critical' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
              severity === 'high' ? 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200' :
              severity === 'medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
              severity === 'low' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' :
              'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
            }`}
          >
            {severity.charAt(0).toUpperCase() + severity.slice(1)}
          </span>
        )}
      </div>

      {change && (
        <Tooltip 
          id={`statcard-${title}-trend`} 
          className="z-50 text-xs font-medium"
        />
      )}
    </div>
  );
};

StatCard.propTypes = {
  title: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
  trend: PropTypes.oneOf(['up', 'down', 'neutral']),
  change: PropTypes.number,
  timeframe: PropTypes.string,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational', 'none']),
  awsService: PropTypes.oneOf(['guardduty', 'cloudtrail', 'iam', 'inspector']),
  isLoading: PropTypes.bool,
  onClick: PropTypes.func,
  className: PropTypes.string,
};

StatCard.defaultProps = {
  trend: 'neutral',
  timeframe: '24h',
  isLoading: false,
  className: '',
};

export default StatCard;