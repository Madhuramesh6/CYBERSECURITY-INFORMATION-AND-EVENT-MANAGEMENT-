import React from 'react';
import PropTypes from 'prop-types';
import {
  InformationCircleIcon,
  ExclamationTriangleIcon,
  ShieldCheckIcon,
  CloudIcon,
  CogIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';
import SeverityPill from './SeverityPill';
import StatusBadge from './StatusBadge';

const SectionHeader = ({
  title,
  description,
  severity,
  status,
  awsService,
  isRefreshable = false,
  isConfigurable = false,
  onRefresh,
  onConfigure,
  className = '',
  ...props
}) => {
  // AWS service icons
  const awsServiceIcons = {
    guardduty: ShieldCheckIcon,
    cloudtrail: ExclamationTriangleIcon,
    cloudwatch: InformationCircleIcon,
    default: CloudIcon
  };

  const ServiceIcon = awsService 
    ? awsServiceIcons[awsService.toLowerCase()] || awsServiceIcons.default 
    : null;

  return (
    <div className={`mb-4 ${className}`} {...props}>
      <div className="flex items-center justify-between">
        <div className="flex items-start space-x-3">
          {/* AWS Service Icon */}
          {awsService && (
            <div className="mt-0.5">
              <div className={`p-2 rounded-lg ${
                severity === 'critical' ? 'bg-red-100 dark:bg-red-900/30' :
                severity === 'high' ? 'bg-orange-100 dark:bg-orange-900/30' :
                severity === 'medium' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                'bg-gray-100 dark:bg-gray-700'
              }`}>
                <ServiceIcon className={`h-5 w-5 ${
                  severity === 'critical' ? 'text-red-500 dark:text-red-400' :
                  severity === 'high' ? 'text-orange-500 dark:text-orange-400' :
                  severity === 'medium' ? 'text-yellow-500 dark:text-yellow-400' :
                  'text-gray-500 dark:text-gray-400'
                }`} />
              </div>
            </div>
          )}

          {/* Title and Description */}
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                {title}
              </h2>
              
              {/* Severity Indicator */}
              {severity && (
                <SeverityPill severity={severity} size="sm" />
              )}

              {/* Status Badge */}
              {status && (
                <StatusBadge status={status} size="sm" />
              )}
            </div>
            
            {description && (
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          {/* Refresh Button */}
          {isRefreshable && (
            <button
              onClick={onRefresh}
              className="inline-flex items-center rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <ArrowPathIcon className="h-4 w-4 mr-1.5" />
              Refresh
            </button>
          )}

          {/* Configuration Button */}
          {isConfigurable && (
            <button
              onClick={onConfigure}
              className="inline-flex items-center rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-1.5 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <CogIcon className="h-4 w-4 mr-1.5" />
              Configure
            </button>
          )}
        </div>
      </div>

      {/* Divider */}
      <div className={`mt-3 border-t ${
        severity === 'critical' ? 'border-red-200 dark:border-red-800' :
        severity === 'high' ? 'border-orange-200 dark:border-orange-800' :
        severity === 'medium' ? 'border-yellow-200 dark:border-yellow-800' :
        'border-gray-200 dark:border-gray-700'
      }`} />
    </div>
  );
};

SectionHeader.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']),
  status: PropTypes.string,
  awsService: PropTypes.oneOf(['guardduty', 'cloudtrail', 'cloudwatch']),
  isRefreshable: PropTypes.bool,
  isConfigurable: PropTypes.bool,
  onRefresh: PropTypes.func,
  onConfigure: PropTypes.func,
  className: PropTypes.string,
};

SectionHeader.defaultProps = {
  description: '',
  severity: null,
  status: null,
  awsService: null,
  isRefreshable: false,
  isConfigurable: false,
  className: '',
};

export default SectionHeader;