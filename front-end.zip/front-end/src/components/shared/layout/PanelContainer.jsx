import React from 'react';
import PropTypes from 'prop-types';
import {
  ChevronDownIcon,
  ChevronUpIcon,
  InformationCircleIcon,
  ExclamationTriangleIcon,
  CloudIcon
} from '@heroicons/react/24/outline';
import StatusBadge from './StatusBadge';

const PanelContainer = ({
  title,
  children,
  severity,
  status,
  isCollapsible = true,
  isExpanded = true,
  onToggle,
  awsService,
  isLoading = false,
  className = '',
  ...props
}) => {
  // Severity colors
  const severityColors = {
    critical: 'border-red-500',
    high: 'border-orange-500',
    medium: 'border-yellow-400',
    low: 'border-blue-400',
    informational: 'border-gray-400',
    none: 'border-gray-200 dark:border-gray-600'
  };

  // AWS service icons
  const awsServiceIcons = {
    guardduty: ShieldExclamationIcon,
    cloudtrail: ExclamationTriangleIcon,
    cloudwatch: InformationCircleIcon,
    default: CloudIcon
  };

  const ServiceIcon = awsService 
    ? awsServiceIcons[awsService.toLowerCase()] || awsServiceIcons.default 
    : null;

  const borderColor = severity ? severityColors[severity] : severityColors.none;

  return (
    <div
      className={`rounded-lg border bg-white dark:bg-gray-800 shadow-sm overflow-hidden ${
        borderColor
      } ${className}`}
      {...props}
    >
      {/* Panel Header */}
      <div 
        className={`flex items-center justify-between px-4 py-3 border-b ${
          severity ? severityColors[severity] : 'border-gray-200 dark:border-gray-700'
        } ${isCollapsible ? 'cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50' : ''}`}
        onClick={isCollapsible ? onToggle : undefined}
      >
        <div className="flex items-center space-x-3">
          {/* AWS Service Icon */}
          {awsService && (
            <div className={`p-1.5 rounded-md ${
              severity === 'critical' ? 'bg-red-100 dark:bg-red-900/30' :
              severity === 'high' ? 'bg-orange-100 dark:bg-orange-900/30' :
              severity === 'medium' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
              'bg-gray-100 dark:bg-gray-700'
            }`}>
              <ServiceIcon className={`h-5 w-5 ${
                severity === 'critical' ? 'text-red-500 dark:text-red-400' :
                severity === 'high' ? 'text-orange-500 dark:text-orange-400' :
                severity === 'medium' ? 'text-yellow-500 dark:text-yellow-400' :
                'text-gray-500 dark:text-gray-400'
              }`} />
            </div>
          )}

          {/* Title */}
          <h3 className="text-base font-medium text-gray-900 dark:text-white">
            {title}
          </h3>

          {/* Status Badge */}
          {status && (
            <StatusBadge 
              status={status} 
              size="sm" 
              className="ml-2"
            />
          )}
        </div>

        {/* Collapse/Expand Button */}
        {isCollapsible && (
          <button
            type="button"
            className="text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400 focus:outline-none"
            onClick={(e) => {
              e.stopPropagation();
              onToggle?.();
            }}
          >
            {isExpanded ? (
              <ChevronUpIcon className="h-5 w-5" aria-hidden="true" />
            ) : (
              <ChevronDownIcon className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        )}
      </div>

      {/* Panel Content */}
      {(!isCollapsible || isExpanded) && (
        <div className="p-4">
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            children
          )}
        </div>
      )}
    </div>
  );
};

PanelContainer.propTypes = {
  title: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']),
  status: PropTypes.string,
  isCollapsible: PropTypes.bool,
  isExpanded: PropTypes.bool,
  onToggle: PropTypes.func,
  awsService: PropTypes.oneOf(['guardduty', 'cloudtrail', 'cloudwatch']),
  isLoading: PropTypes.bool,
  className: PropTypes.string,
};

PanelContainer.defaultProps = {
  severity: null,
  status: null,
  isCollapsible: true,
  isExpanded: true,
  isLoading: false,
  className: '',
};

export default PanelContainer;