import React from 'react';
import PropTypes from 'prop-types';
import { ArrowPathIcon, CheckIcon, ExclamationTriangleIcon } from '@heroicons/react/24/solid';

const ActionButton = ({
  children,
  onClick,
  variant = 'primary',
  size = 'medium',
  isLoading = false,
  isSuccess = false,
  isError = false,
  disabled = false,
  icon: Icon,
  awsAction = false,
  fullWidth = false,
  className = '',
  ...props
}) => {
  // Variant styles
  const variantStyles = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white focus:ring-blue-500',
    danger: 'bg-red-600 hover:bg-red-700 text-white focus:ring-red-500',
    success: 'bg-green-600 hover:bg-green-700 text-white focus:ring-green-500',
    warning: 'bg-yellow-500 hover:bg-yellow-600 text-white focus:ring-yellow-500',
    'aws-primary': 'bg-aws-orange hover:bg-aws-dark-orange text-white focus:ring-aws-orange',
    'aws-secondary': 'bg-gray-200 hover:bg-gray-300 text-aws-dark-gray focus:ring-gray-500',
  };

  // Size styles
  const sizeStyles = {
    small: 'px-3 py-1.5 text-sm',
    medium: 'px-4 py-2 text-base',
    large: 'px-6 py-3 text-lg',
  };

  // State icons
  const StateIcon = () => {
    if (isLoading) return <ArrowPathIcon className="h-5 w-5 animate-spin" />;
    if (isSuccess) return <CheckIcon className="h-5 w-5" />;
    if (isError) return <ExclamationTriangleIcon className="h-5 w-5" />;
    return Icon ? <Icon className="h-5 w-5" /> : null;
  };

  // Determine the current variant
  const currentVariant = awsAction ? `aws-${variant}` : variant;

  return (
    <button
      onClick={onClick}
      disabled={disabled || isLoading}
      className={`
        inline-flex items-center justify-center rounded-md border border-transparent
        font-medium shadow-sm transition-all duration-150 focus:outline-none focus:ring-2
        focus:ring-offset-2 disabled:opacity-70 disabled:cursor-not-allowed
        ${variantStyles[currentVariant] || variantStyles.primary}
        ${sizeStyles[size]}
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
      {...props}
    >
      {isLoading || isSuccess || isError || Icon ? (
        <span className={`flex items-center ${children ? 'mr-2' : ''}`}>
          <StateIcon />
        </span>
      ) : null}
      {children}
    </button>
  );
};

ActionButton.propTypes = {
  children: PropTypes.node,
  onClick: PropTypes.func.isRequired,
  variant: PropTypes.oneOf(['primary', 'danger', 'success', 'warning']),
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  isLoading: PropTypes.bool,
  isSuccess: PropTypes.bool,
  isError: PropTypes.bool,
  disabled: PropTypes.bool,
  icon: PropTypes.elementType,
  awsAction: PropTypes.bool,
  fullWidth: PropTypes.bool,
  className: PropTypes.string,
};

export default ActionButton;