import React from 'react';
import PropTypes from 'prop-types';
import { 
  ArrowPathIcon,
  ShieldCheckIcon,
  ShieldExclamationIcon,
  FireIcon,
  BoltIcon,
  InformationCircleIcon
} from '@heroicons/react/24/solid';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

const SeverityButton = ({
  severity,
  count = 0,
  onClick,
  isActive = false,
  isLoading = false,
  showCount = true,
  size = 'medium',
  interactive = true,
  className = '',
  ...props
}) => {
  // Severity configuration
  const severityConfig = {
    critical: {
      icon: FireIcon,
      bg: 'bg-red-600',
      hover: 'hover:bg-red-700',
      text: 'text-white',
      border: 'border-red-700',
      label: 'Critical',
      awsEquivalent: 'HIGH'
    },
    high: {
      icon: ShieldExclamationIcon,
      bg: 'bg-orange-500',
      hover: 'hover:bg-orange-600',
      text: 'text-white',
      border: 'border-orange-600',
      label: 'High',
      awsEquivalent: 'MEDIUM'
    },
    medium: {
      icon: BoltIcon,
      bg: 'bg-yellow-400',
      hover: 'hover:bg-yellow-500',
      text: 'text-gray-800',
      border: 'border-yellow-500',
      label: 'Medium',
      awsEquivalent: 'LOW'
    },
    low: {
      icon: ShieldCheckIcon,
      bg: 'bg-blue-400',
      hover: 'hover:bg-blue-500',
      text: 'text-white',
      border: 'border-blue-500',
      label: 'Low',
      awsEquivalent: 'INFO'
    },
    informational: {
      icon: InformationCircleIcon,
      bg: 'bg-gray-400',
      hover: 'hover:bg-gray-500',
      text: 'text-white',
      border: 'border-gray-500',
      label: 'Info',
      awsEquivalent: 'MINOR'
    }
  };

  const currentConfig = severityConfig[severity] || severityConfig.informational;
  const Icon = isLoading ? ArrowPathIcon : currentConfig.icon;

  // Size classes
  const sizeClasses = {
    small: 'px-2 py-1 text-xs',
    medium: 'px-3 py-1.5 text-sm',
    large: 'px-4 py-2 text-base'
  };

  return (
    <>
      <button
        onClick={onClick}
        disabled={!interactive || isLoading}
        data-tooltip-id={`severity-${severity}`}
        data-tooltip-content={`${currentConfig.label} threats (AWS ${currentConfig.awsEquivalent})`}
        className={`
          inline-flex items-center rounded-md border font-medium
          transition-all duration-200 focus:outline-none focus:ring-2
          focus:ring-offset-2 focus:ring-blue-500
          ${currentConfig.bg}
          ${interactive ? currentConfig.hover : ''}
          ${currentConfig.text}
          ${currentConfig.border}
          ${isActive ? 'ring-2 ring-offset-2 ring-blue-500' : ''}
          ${isLoading ? 'cursor-wait' : interactive ? 'cursor-pointer' : 'cursor-default'}
          ${sizeClasses[size]}
          ${className}
        `}
        {...props}
      >
        {isLoading ? (
          <Icon className={`animate-spin h-4 w-4 ${showCount ? 'mr-1.5' : ''}`} />
        ) : (
          <Icon className={`h-4 w-4 ${showCount ? 'mr-1.5' : ''}`} />
        )}
        {showCount && (
          <span className="font-semibold">
            {count > 99 ? '99+' : count}
          </span>
        )}
      </button>

      <Tooltip 
        id={`severity-${severity}`} 
        className="z-50 text-xs font-medium"
        place="top"
      />
    </>
  );
};

SeverityButton.propTypes = {
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']).isRequired,
  count: PropTypes.number,
  onClick: PropTypes.func,
  isActive: PropTypes.bool,
  isLoading: PropTypes.bool,
  showCount: PropTypes.bool,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  interactive: PropTypes.bool,
  className: PropTypes.string,
};

SeverityButton.defaultProps = {
  count: 0,
  onClick: () => {},
  isActive: false,
  isLoading: false,
  showCount: true,
  size: 'medium',
  interactive: true,
  className: '',
};

export default SeverityButton;