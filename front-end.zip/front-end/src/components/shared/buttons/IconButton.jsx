import React from 'react';
import PropTypes from 'prop-types';
import { Tooltip } from 'react-tooltip';
import 'react-tooltip/dist/react-tooltip.css';

const IconButton = ({
  icon: Icon,
  onClick,
  size = 'medium',
  variant = 'ghost',
  ariaLabel,
  tooltip,
  tooltipPosition = 'top',
  isLoading = false,
  disabled = false,
  badgeCount,
  isActive = false,
  awsService, // Optional AWS service name for service-specific styling
  className = '',
  ...props
}) => {
  // Size classes
  const sizeClasses = {
    small: 'p-1.5 text-sm',
    medium: 'p-2 text-base',
    large: 'p-3 text-lg',
  };

  // Variant classes
  const variantClasses = {
    ghost: 'bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700',
    solid: 'bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600',
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    danger: 'bg-red-600 hover:bg-red-700 text-white',
    'aws-primary': 'bg-aws-orange hover:bg-aws-dark-orange text-white',
  };

  // AWS service specific icons
  const awsServiceColors = {
    guardduty: 'text-purple-600 dark:text-purple-400',
    cloudtrail: 'text-blue-600 dark:text-blue-400',
    iam: 'text-red-600 dark:text-red-400',
    kinesis: 'text-green-600 dark:text-green-400',
    default: 'text-gray-700 dark:text-gray-300',
  };

  const awsColorClass = awsService 
    ? awsServiceColors[awsService.toLowerCase()] || awsServiceColors.default
    : '';

  return (
    <>
      <button
        onClick={onClick}
        disabled={disabled || isLoading}
        aria-label={ariaLabel}
        data-tooltip-id={`icon-btn-${ariaLabel}`}
        data-tooltip-content={tooltip}
        className={`
          inline-flex items-center justify-center rounded-md 
          transition-all duration-200 focus:outline-none focus:ring-2 
          focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 
          disabled:cursor-not-allowed relative
          ${sizeClasses[size]}
          ${variantClasses[variant]}
          ${awsService ? awsColorClass : ''}
          ${isActive ? 'ring-2 ring-blue-500' : ''}
          ${className}
        `}
        {...props}
      >
        {isLoading ? (
          <svg
            className="animate-spin h-5 w-5"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            ></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
        ) : (
          <>
            <Icon className={`h-5 w-5 ${awsService ? '' : 'text-current'}`} />
            {badgeCount && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {badgeCount > 9 ? '9+' : badgeCount}
              </span>
            )}
          </>
        )}
      </button>

      {tooltip && (
        <Tooltip
          id={`icon-btn-${ariaLabel}`}
          place={tooltipPosition}
          className="z-50 text-xs font-medium"
        />
      )}
    </>
  );
};

IconButton.propTypes = {
  icon: PropTypes.elementType.isRequired,
  onClick: PropTypes.func.isRequired,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  variant: PropTypes.oneOf(['ghost', 'solid', 'primary', 'danger', 'aws-primary']),
  ariaLabel: PropTypes.string.isRequired,
  tooltip: PropTypes.string,
  tooltipPosition: PropTypes.oneOf(['top', 'right', 'bottom', 'left']),
  isLoading: PropTypes.bool,
  disabled: PropTypes.bool,
  badgeCount: PropTypes.number,
  isActive: PropTypes.bool,
  awsService: PropTypes.oneOf(['guardduty', 'cloudtrail', 'iam', 'kinesis', 'cloudwatch']),
  className: PropTypes.string,
};

export default IconButton;