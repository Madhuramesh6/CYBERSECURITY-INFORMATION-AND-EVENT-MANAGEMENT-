import React from 'react';
import PropTypes from 'prop-types';
import {
  XMarkIcon,
  ArrowTopRightOnSquareIcon,
  ShieldExclamationIcon,
  CodeBracketIcon,
  ClockIcon,
  CloudIcon,
  MapPinIcon,
  UserIcon
} from '@heroicons/react/24/outline';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import JsonViewer from './JsonViewer';
import SeverityPill from './SeverityPill';
import { format } from 'date-fns';

const AlertDetailsModal = ({
  isOpen,
  onClose,
  alert,
  awsResources = [],
  relatedAlerts = [],
  onAwsConsoleClick,
  className = '',
  ...props
}) => {
  if (!alert) return null;

  // Format timestamp
  const formattedDate = format(new Date(alert.timestamp), 'PPpp');
  const timeAgo = formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true });

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black bg-opacity-50" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className={`w-full max-w-4xl transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 text-left align-middle shadow-xl transition-all ${className}`}>
                {/* Header */}
                <div className="flex justify-between items-start p-6 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-lg ${
                      alert.severity === 'critical' ? 'bg-red-100 dark:bg-red-900/30' :
                      alert.severity === 'high' ? 'bg-orange-100 dark:bg-orange-900/30' :
                      alert.severity === 'medium' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                      'bg-blue-100 dark:bg-blue-900/30'
                    }`}>
                      <ShieldExclamationIcon className={`h-6 w-6 ${
                        alert.severity === 'critical' ? 'text-red-600 dark:text-red-400' :
                        alert.severity === 'high' ? 'text-orange-600 dark:text-orange-400' :
                        alert.severity === 'medium' ? 'text-yellow-600 dark:text-yellow-400' :
                        'text-blue-600 dark:text-blue-400'
                      }`} />
                    </div>
                    <div>
                      <Dialog.Title as="h3" className="text-lg font-medium text-gray-900 dark:text-white">
                        {alert.title}
                      </Dialog.Title>
                      <div className="mt-1 flex items-center space-x-2">
                        <SeverityPill severity={alert.severity} />
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {alert.source}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="rounded-md bg-white dark:bg-gray-800 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 focus:outline-none"
                    onClick={onClose}
                  >
                    <XMarkIcon className="h-5 w-5" aria-hidden="true" />
                  </button>
                </div>

                {/* Body */}
                <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Main Content */}
                  <div className="md:col-span-2 space-y-6">
                    <div>
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Description</h4>
                      <p className="text-sm text-gray-800 dark:text-gray-200">{alert.description}</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center">
                          <ClockIcon className="h-4 w-4 mr-2" />
                          Timing
                        </h4>
                        <p className="text-sm text-gray-800 dark:text-gray-200">
                          <span className="font-medium">Detected:</span> {formattedDate}<br />
                          <span className="text-xs text-gray-500 dark:text-gray-400">({timeAgo})</span>
                        </p>
                        {alert.eventDuration && (
                          <p className="text-sm text-gray-800 dark:text-gray-200 mt-1">
                            <span className="font-medium">Duration:</span> {alert.eventDuration}
                          </p>
                        )}
                      </div>

                      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center">
                          <MapPinIcon className="h-4 w-4 mr-2" />
                          Source
                        </h4>
                        <p className="text-sm text-gray-800 dark:text-gray-200">
                          <span className="font-medium">IP:</span> {alert.sourceIp || 'Unknown'}<br />
                          <span className="font-medium">Location:</span> {alert.geoLocation || 'Unknown'}
                        </p>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center">
                        <UserIcon className="h-4 w-4 mr-2" />
                        Affected Resources
                      </h4>
                      <div className="space-y-2">
                        {awsResources.map(resource => (
                          <div key={resource.arn} className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                            <div>
                              <p className="text-sm font-medium text-gray-800 dark:text-gray-200">{resource.type}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{resource.arn}</p>
                            </div>
                            <button
                              onClick={() => onAwsConsoleClick(resource.arn)}
                              className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 text-sm font-medium flex items-center"
                            >
                              AWS Console
                              <ArrowTopRightOnSquareIcon className="h-4 w-4 ml-1" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center">
                        <CodeBracketIcon className="h-4 w-4 mr-2" />
                        Raw Alert Data
                      </h4>
                      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <JsonViewer data={alert.raw} />
                      </div>
                    </div>
                  </div>

                  {/* Sidebar */}
                  <div className="space-y-6">
                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">Alert Actions</h4>
                      <div className="space-y-2">
                        <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md text-sm font-medium">
                          Mark as Investigated
                        </button>
                        <button className="w-full bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500 text-gray-800 dark:text-white py-2 px-4 rounded-md text-sm font-medium">
                          Add to Case
                        </button>
                        <button className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-md text-sm font-medium">
                          Create Suppression Rule
                        </button>
                      </div>
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">Related Alerts</h4>
                      {relatedAlerts.length > 0 ? (
                        <ul className="space-y-2">
                          {relatedAlerts.slice(0, 3).map(related => (
                            <li key={related.id} className="text-sm text-gray-800 dark:text-gray-200 p-2 hover:bg-gray-100 dark:hover:bg-gray-600 rounded-md cursor-pointer">
                              <div className="flex items-center justify-between">
                                <span className="truncate">{related.title}</span>
                                <SeverityPill severity={related.severity} size="xs" />
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                {format(new Date(related.timestamp), 'PPpp')}
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No related alerts found</p>
                      )}
                    </div>

                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-3">Threat Intelligence</h4>
                      {alert.threatIntel ? (
                        <div className="space-y-2">
                          <p className="text-sm text-gray-800 dark:text-gray-200">
                            <span className="font-medium">Match:</span> {alert.threatIntel.type}
                          </p>
                          <p className="text-sm text-gray-800 dark:text-gray-200">
                            <span className="font-medium">Confidence:</span> {alert.threatIntel.confidence}/10
                          </p>
                          <p className="text-sm text-gray-800 dark:text-gray-200">
                            <span className="font-medium">Source:</span> {alert.threatIntel.source}
                          </p>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No threat intelligence matches</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <CloudIcon className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      AWS Region: {alert.awsRegion || 'Unknown'}
                    </span>
                  </div>
                  <div className="flex space-x-3">
                    <button
                      type="button"
                      className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600"
                      onClick={onClose}
                    >
                      Close
                    </button>
                    <button
                      type="button"
                      className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
                      onClick={() => {
                        // Handle alert action
                        onClose();
                      }}
                    >
                      Take Action
                    </button>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

AlertDetailsModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  alert: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']).isRequired,
    source: PropTypes.string.isRequired,
    timestamp: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    sourceIp: PropTypes.string,
    geoLocation: PropTypes.string,
    awsRegion: PropTypes.string,
    eventDuration: PropTypes.string,
    raw: PropTypes.object,
    threatIntel: PropTypes.shape({
      type: PropTypes.string,
      confidence: PropTypes.number,
      source: PropTypes.string
    })
  }),
  awsResources: PropTypes.arrayOf(
    PropTypes.shape({
      arn: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired
    })
  ),
  relatedAlerts: PropTypes.array,
  onAwsConsoleClick: PropTypes.func,
  className: PropTypes.string,
};

AlertDetailsModal.defaultProps = {
  awsResources: [],
  relatedAlerts: [],
  onAwsConsoleClick: () => {},
  className: '',
};

export default AlertDetailsModal;