import React from 'react';
import PropTypes from 'prop-types';
import { 
  ExclamationTriangleIcon,
  TrashIcon,
  XMarkIcon,
  ArrowPathIcon
} from '@heroicons/react/24/solid';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';

const ConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  title = "Confirm Action",
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  severity = "medium",
  isLoading = false,
  awsService,
  resourceName,
  className = '',
  ...props
}) => {
  // Severity configuration
  const severityConfig = {
    critical: {
      icon: ExclamationTriangleIcon,
      iconColor: 'text-red-500',
      buttonColor: 'bg-red-600 hover:bg-red-700 focus-visible:ring-red-500',
    },
    high: {
      icon: ExclamationTriangleIcon,
      iconColor: 'text-orange-500',
      buttonColor: 'bg-orange-600 hover:bg-orange-700 focus-visible:ring-orange-500',
    },
    medium: {
      icon: ExclamationTriangleIcon,
      iconColor: 'text-yellow-500',
      buttonColor: 'bg-yellow-600 hover:bg-yellow-700 focus-visible:ring-yellow-500',
    },
    low: {
      icon: ExclamationTriangleIcon,
      iconColor: 'text-blue-500',
      buttonColor: 'bg-blue-600 hover:bg-blue-700 focus-visible:ring-blue-500',
    },
    aws: {
      icon: ExclamationTriangleIcon,
      iconColor: 'text-aws-orange',
      buttonColor: 'bg-aws-orange hover:bg-aws-dark-orange focus-visible:ring-aws-orange',
    }
  };

  const currentSeverity = awsService ? 'aws' : severity;
  const { icon: Icon, iconColor, buttonColor } = severityConfig[currentSeverity];

  return (
    <Transition appear show={isOpen} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black bg-opacity-50" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 scale-95"
              enterTo="opacity-100 scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 scale-100"
              leaveTo="opacity-0 scale-95"
            >
              <Dialog.Panel className={`w-full max-w-md transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 text-left align-middle shadow-xl transition-all ${className}`}>
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <div className={`mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full ${iconColor} bg-opacity-20`}>
                      <Icon className="h-6 w-6" aria-hidden="true" />
                    </div>
                    <Dialog.Title
                      as="h3"
                      className="ml-3 text-lg font-medium leading-6 text-gray-900 dark:text-white"
                    >
                      {title}
                    </Dialog.Title>
                  </div>
                  <button
                    type="button"
                    className="rounded-md bg-white dark:bg-gray-800 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 focus:outline-none"
                    onClick={onClose}
                  >
                    <XMarkIcon className="h-5 w-5" aria-hidden="true" />
                  </button>
                </div>

                <div className="mt-4">
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {message}
                  </p>
                  {resourceName && (
                    <div className="mt-3 px-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-md">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300 break-all">
                        {resourceName}
                      </p>
                      {awsService && (
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                          AWS {awsService.charAt(0).toUpperCase() + awsService.slice(1)}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    className="inline-flex justify-center rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"
                    onClick={onClose}
                    disabled={isLoading}
                  >
                    {cancelText}
                  </button>
                  <button
                    type="button"
                    className={`inline-flex justify-center rounded-md border border-transparent px-4 py-2 text-sm font-medium text-white ${buttonColor} focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2`}
                    onClick={onConfirm}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <ArrowPathIcon className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      confirmText
                    )}
                  </button>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
};

ConfirmationModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onConfirm: PropTypes.func.isRequired,
  title: PropTypes.string,
  message: PropTypes.string.isRequired,
  confirmText: PropTypes.string,
  cancelText: PropTypes.string,
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low']),
  isLoading: PropTypes.bool,
  awsService: PropTypes.oneOf([
    'guardduty', 'cloudtrail', 'iam', 'kinesis', 'lambda', 's3', 'ec2'
  ]),
  resourceName: PropTypes.string,
  className: PropTypes.string,
};

ConfirmationModal.defaultProps = {
  title: "Confirm Action",
  confirmText: "Confirm",
  cancelText: "Cancel",
  severity: "medium",
  isLoading: false,
  className: '',
};

export default ConfirmationModal;