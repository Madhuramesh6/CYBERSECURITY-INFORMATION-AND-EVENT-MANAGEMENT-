import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { 
  CalendarIcon,
  ClockIcon,
  ArrowPathIcon,
  ChevronDownIcon
} from '@heroicons/react/24/outline';
import { Menu, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useAWS } from '../../hooks/useAWS';

const TimeRangePicker = ({
  initialRange = 'last24hours',
  onTimeChange,
  timezone = 'UTC',
  showRelativeOptions = true,
  showAbsolutePicker = true,
  showRefresh = true,
  className = '',
  ...props
}) => {
  const { getCloudWatchTime } = useAWS();
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(new Date());
  const [selectedRange, setSelectedRange] = useState(initialRange);
  const [isCustom, setIsCustom] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Predefined time ranges
  const timeRanges = [
    { value: 'last5minutes', label: 'Last 5 minutes', getRange: () => getCloudWatchTime('5m') },
    { value: 'last1hour', label: 'Last 1 hour', getRange: () => getCloudWatchTime('1h') },
    { value: 'last3hours', label: 'Last 3 hours', getRange: () => getCloudWatchTime('3h') },
    { value: 'last24hours', label: 'Last 24 hours', getRange: () => getCloudWatchTime('24h') },
    { value: 'last7days', label: 'Last 7 days', getRange: () => getCloudWatchTime('7d') },
    { value: 'last30days', label: 'Last 30 days', getRange: () => getCloudWatchTime('30d') },
    { value: 'custom', label: 'Custom range', getRange: () => ({ start: startDate, end: endDate }) }
  ];

  // Handle time range selection
  const handleRangeSelect = async (range) => {
    if (range.value === 'custom') {
      setIsCustom(true);
      return;
    }

    setIsCustom(false);
    setSelectedRange(range.value);
    const { start, end } = await range.getRange();
    setStartDate(start);
    setEndDate(end);
    onTimeChange({ start, end, range: range.value });
  };

  // Handle custom date change
  const handleCustomDateChange = (dates) => {
    const [start, end] = dates;
    setStartDate(start);
    setEndDate(end);
    if (start && end) {
      setSelectedRange('custom');
      onTimeChange({ start, end, range: 'custom' });
    }
  };

  // Handle refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      const range = timeRanges.find(r => r.value === selectedRange);
      if (range) {
        const { start, end } = await range.getRange();
        setStartDate(start);
        setEndDate(end);
        onTimeChange({ start, end, range: selectedRange });
      }
    } finally {
      setIsRefreshing(false);
    }
  };

  // Initialize with default range
  useEffect(() => {
    const initialize = async () => {
      const defaultRange = timeRanges.find(r => r.value === initialRange) || timeRanges[3];
      const { start, end } = await defaultRange.getRange();
      setStartDate(start);
      setEndDate(end);
    };
    initialize();
  }, []);

  // Format date for display
  const formatDate = (date) => {
    if (!date) return 'Select date';
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: timezone
    });
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`} {...props}>
      {/* Relative time range dropdown */}
      {showRelativeOptions && (
        <Menu as="div" className="relative inline-block text-left">
          <div>
            <Menu.Button className="inline-flex w-full justify-center rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <ClockIcon className="h-5 w-5 mr-2 text-gray-400 dark:text-gray-500" />
              {timeRanges.find(r => r.value === selectedRange)?.label || 'Select range'}
              <ChevronDownIcon className="ml-2 -mr-1 h-5 w-5 text-gray-400 dark:text-gray-500" aria-hidden="true" />
            </Menu.Button>
          </div>

          <Transition
            as={Fragment}
            enter="transition ease-out duration-100"
            enterFrom="transform opacity-0 scale-95"
            enterTo="transform opacity-100 scale-100"
            leave="transition ease-in duration-75"
            leaveFrom="transform opacity-100 scale-100"
            leaveTo="transform opacity-0 scale-95"
          >
            <Menu.Items className="absolute left-0 z-10 mt-2 w-56 origin-top-left rounded-md bg-white dark:bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
              <div className="py-1">
                {timeRanges.filter(r => r.value !== 'custom').map((range) => (
                  <Menu.Item key={range.value}>
                    {({ active }) => (
                      <button
                        onClick={() => handleRangeSelect(range)}
                        className={`block w-full px-4 py-2 text-left text-sm ${
                          active ? 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-200'
                        }`}
                      >
                        {range.label}
                      </button>
                    )}
                  </Menu.Item>
                ))}
                {showAbsolutePicker && (
                  <Menu.Item>
                    {({ active }) => (
                      <button
                        onClick={() => handleRangeSelect(timeRanges.find(r => r.value === 'custom'))}
                        className={`block w-full px-4 py-2 text-left text-sm ${
                          active ? 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white' : 'text-gray-700 dark:text-gray-200'
                        }`}
                      >
                        Custom range
                      </button>
                    )}
                  </Menu.Item>
                )}
              </div>
            </Menu.Items>
          </Transition>
        </Menu>
      )}

      {/* Absolute date picker */}
      {showAbsolutePicker && (isCustom || !showRelativeOptions) && (
        <div className="flex items-center space-x-2">
          <div className="relative">
            <DatePicker
              selectsRange
              startDate={startDate}
              endDate={endDate}
              onChange={handleCustomDateChange}
              isClearable
              showTimeSelect
              timeFormat="HH:mm"
              timeIntervals={15}
              dateFormat="MMM d, yyyy HH:mm"
              placeholderText="Select date range"
              className="rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-4 py-2 text-sm text-gray-700 dark:text-gray-200 shadow-sm focus:ring-blue-500 focus:border-blue-500 w-64"
            />
            <CalendarIcon className="h-5 w-5 absolute right-3 top-2.5 text-gray-400 dark:text-gray-500 pointer-events-none" />
          </div>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {timezone}
          </span>
        </div>
      )}

      {/* Refresh button */}
      {showRefresh && (
        <button
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="inline-flex items-center rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <ArrowPathIcon className={`h-5 w-5 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      )}

      {/* Current range display */}
      <div className="hidden md:flex items-center text-sm text-gray-500 dark:text-gray-400">
        <span className="mr-1">Showing:</span>
        {selectedRange === 'custom' ? (
          <>
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {formatDate(startDate)}
            </span>
            <span className="mx-1">to</span>
            <span className="font-medium text-gray-700 dark:text-gray-300">
              {formatDate(endDate)}
            </span>
          </>
        ) : (
          <span className="font-medium text-gray-700 dark:text-gray-300">
            {timeRanges.find(r => r.value === selectedRange)?.label}
          </span>
        )}
      </div>
    </div>
  );
};

TimeRangePicker.propTypes = {
  initialRange: PropTypes.oneOf([
    'last5minutes',
    'last1hour',
    'last3hours',
    'last24hours',
    'last7days',
    'last30days',
    'custom'
  ]),
  onTimeChange: PropTypes.func.isRequired,
  timezone: PropTypes.string,
  showRelativeOptions: PropTypes.bool,
  showAbsolutePicker: PropTypes.bool,
  showRefresh: PropTypes.bool,
  className: PropTypes.string,
};

TimeRangePicker.defaultProps = {
  initialRange: 'last24hours',
  timezone: 'UTC',
  showRelativeOptions: true,
  showAbsolutePicker: true,
  showRefresh: true,
  className: '',
};

export default TimeRangePicker;