import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  MagnifyingGlassIcon,
  XMarkIcon,
  CommandLineIcon,
  ShieldExclamationIcon,
  CloudIcon
} from '@heroicons/react/24/outline';
import { useDebounce } from '../../hooks/useDebounce';
import { useAWS } from '../../hooks/useAWS';

const SearchInput = ({
  initialQuery = '',
  onSearch,
  searchType = 'logs',
  placeholder = 'Search...',
  debounceTime = 300,
  showFilters = true,
  className = '',
  ...props
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [isAdvanced, setIsAdvanced] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState(searchType);
  const debouncedQuery = useDebounce(query, debounceTime);
  const { getCloudWatchQuerySyntax } = useAWS();

  // Search type filters
  const searchFilters = [
    { value: 'logs', label: 'Logs', icon: CommandLineIcon },
    { value: 'threats', label: 'Threats', icon: ShieldExclamationIcon },
    { value: 'aws', label: 'AWS', icon: CloudIcon }
  ];

  // Handle search execution
  useEffect(() => {
    if (debouncedQuery.trim() !== '' || debouncedQuery !== initialQuery) {
      let processedQuery = debouncedQuery;
      
      // Apply CloudWatch query syntax if searching logs
      if (selectedFilter === 'logs' && isAdvanced) {
        processedQuery = getCloudWatchQuerySyntax(debouncedQuery);
      }

      onSearch({
        query: processedQuery,
        type: selectedFilter,
        isAdvanced: selectedFilter === 'logs' && isAdvanced
      });
    }
  }, [debouncedQuery, selectedFilter, isAdvanced]);

  // Handle filter change
  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
    setIsAdvanced(false);
    setQuery('');
  };

  // Toggle advanced search
  const toggleAdvanced = () => {
    setIsAdvanced(!isAdvanced);
  };

  // Clear search
  const clearSearch = () => {
    setQuery('');
    onSearch({ query: '', type: selectedFilter, isAdvanced: false });
  };

  return (
    <div className={`relative ${className}`} {...props}>
      {/* Search input */}
      <div className="relative flex items-center">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 dark:text-gray-500" />
        </div>

        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={
            selectedFilter === 'logs' && isAdvanced 
              ? 'Enter CloudWatch query (e.g., status:404)'
              : placeholder
          }
          className={`block w-full pl-10 pr-12 py-2 border ${
            isAdvanced ? 'border-blue-500' : 'border-gray-300 dark:border-gray-600'
          } rounded-md bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 ${
            isAdvanced ? 'focus:ring-blue-500' : 'focus:ring-gray-500'
          } focus:border-transparent sm:text-sm`}
        />

        {query && (
          <button
            onClick={clearSearch}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 dark:text-gray-500 hover:text-gray-500 dark:hover:text-gray-400"
          >
            <XMarkIcon className="h-5 w-5" />
          </button>
        )}
      </div>

      {/* Search controls */}
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
        {/* Search type filters */}
        {showFilters && (
          <div className="flex space-x-1">
            {searchFilters.map((filter) => (
              <button
                key={filter.value}
                onClick={() => handleFilterChange(filter.value)}
                className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                  selectedFilter === filter.value
                    ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <filter.icon className="h-3 w-3 mr-1" />
                {filter.label}
              </button>
            ))}
          </div>
        )}

        {/* Advanced search toggle */}
        {selectedFilter === 'logs' && (
          <button
            onClick={toggleAdvanced}
            className={`ml-auto text-xs font-medium ${
              isAdvanced 
                ? 'text-blue-600 dark:text-blue-400'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            {isAdvanced ? 'Switch to basic search' : 'Advanced CloudWatch search'}
          </button>
        )}
      </div>

      {/* Advanced search hint */}
      {isAdvanced && selectedFilter === 'logs' && (
        <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200 text-xs rounded-md">
          <p>Use CloudWatch query syntax. Examples:</p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li><code className="bg-blue-100 dark:bg-blue-900/30 px-1 rounded">error | stats count(*) by bin(5m)</code></li>
            <li><code className="bg-blue-100 dark:bg-blue-900/30 px-1 rounded">(status:4* OR status:5*) | sort @timestamp desc</code></li>
            <li><code className="bg-blue-100 dark:bg-blue-900/30 px-1 rounded">filter sourceIP = "192.0.2.1"</code></li>
          </ul>
        </div>
      )}
    </div>
  );
};

SearchInput.propTypes = {
  initialQuery: PropTypes.string,
  onSearch: PropTypes.func.isRequired,
  searchType: PropTypes.oneOf(['logs', 'threats', 'aws']),
  placeholder: PropTypes.string,
  debounceTime: PropTypes.number,
  showFilters: PropTypes.bool,
  className: PropTypes.string,
};

SearchInput.defaultProps = {
  initialQuery: '',
  searchType: 'logs',
  placeholder: 'Search...',
  debounceTime: 300,
  showFilters: true,
  className: '',
};

export default SearchInput;