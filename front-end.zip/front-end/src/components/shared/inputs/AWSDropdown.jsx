import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { 
  ChevronUpDownIcon,
  CheckIcon,
  MagnifyingGlassIcon,
  CloudIcon,
  ShieldCheckIcon,
  ExclamationTriangleIcon,
  LockClosedIcon,
  ServerIcon
} from '@heroicons/react/24/outline';
import { Combobox } from '@headlessui/react';
import { useAWS } from '../../hooks/useAWS';

const AWSDropdown = ({
  selectedItems,
  onSelect,
  serviceFilter,
  regionFilter,
  maxSelections = 3,
  showIcons = true,
  withSearch = true,
  className = '',
  ...props
}) => {
  const { getAWSResources } = useAWS();
  const [resources, setResources] = useState([]);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Fetch AWS resources based on filters
  useEffect(() => {
    const fetchResources = async () => {
      setIsLoading(true);
      try {
        const data = await getAWSResources({
          service: serviceFilter,
          region: regionFilter
        });
        setResources(data);
      } catch (error) {
        console.error('Failed to fetch AWS resources:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchResources();
  }, [serviceFilter, regionFilter, getAWSResources]);

  // Filter resources based on search query
  const filteredResources = query === ''
    ? resources
    : resources.filter((resource) => {
        return resource.name.toLowerCase().includes(query.toLowerCase()) ||
               resource.arn.toLowerCase().includes(query.toLowerCase()) ||
               resource.type.toLowerCase().includes(query.toLowerCase());
      });

  // Get icon for AWS service type
  const getServiceIcon = (serviceType) => {
    switch(serviceType.toLowerCase()) {
      case 'iam':
        return <LockClosedIcon className="h-5 w-5 text-yellow-500" />;
      case 'guardduty':
      case 'securityhub':
        return <ShieldCheckIcon className="h-5 w-5 text-blue-500" />;
      case 'ec2':
        return <ServerIcon className="h-5 w-5 text-green-500" />;
      case 'cloudtrail':
      case 'cloudwatch':
        return <ExclamationTriangleIcon className="h-5 w-5 text-orange-500" />;
      default:
        return <CloudIcon className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <Combobox 
      as="div" 
      value={selectedItems} 
      onChange={onSelect}
      multiple
      disabled={isLoading}
      className={`relative ${className}`}
      {...props}
    >
      {({ open }) => (
        <>
          <div className="relative">
            <Combobox.Button className="w-full">
              <div className={`relative w-full cursor-default rounded-md border ${
                open ? 'border-blue-500 ring-1 ring-blue-500' : 'border-gray-300 dark:border-gray-600'
              } bg-white dark:bg-gray-800 py-2 pl-3 pr-10 text-left shadow-sm focus:outline-none sm:text-sm`}>
                <span className="flex items-center flex-wrap gap-2">
                  {selectedItems.length === 0 ? (
                    <span className="text-gray-500 dark:text-gray-400">Select AWS resources...</span>
                  ) : (
                    selectedItems.slice(0, maxSelections).map((item) => (
                      <span 
                        key={item.arn}
                        className="inline-flex items-center rounded bg-blue-50 dark:bg-blue-900/30 px-2 py-1 text-xs font-medium text-blue-700 dark:text-blue-200"
                      >
                        {showIcons && getServiceIcon(item.type)}
                        <span className="ml-1 truncate max-w-[120px]">{item.name}</span>
                      </span>
                    ))
                  )}
                  {selectedItems.length > maxSelections && (
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      +{selectedItems.length - maxSelections} more
                    </span>
                  )}
                </span>
                <span className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2">
                  <ChevronUpDownIcon className="h-5 w-5 text-gray-400 dark:text-gray-500" aria-hidden="true" />
                </span>
              </div>
            </Combobox.Button>

            {withSearch && (
              <Combobox.Input
                className="w-full rounded-md border-0 bg-white dark:bg-gray-800 py-1.5 pl-3 pr-10 text-gray-900 dark:text-white shadow-sm ring-1 ring-inset ring-gray-300 dark:ring-gray-600 focus:ring-2 focus:ring-inset focus:ring-blue-500 sm:text-sm sm:leading-6"
                onChange={(event) => setQuery(event.target.value)}
                displayValue={(items) => items.map(item => item.name).join(', ')}
                placeholder="Search AWS resources..."
              />
            )}
          </div>

          <Combobox.Options className="absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-md bg-white dark:bg-gray-800 py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
            {isLoading ? (
              <div className="relative cursor-default select-none py-2 pl-3 pr-9 text-gray-700 dark:text-gray-300">
                Loading AWS resources...
              </div>
            ) : filteredResources.length === 0 && query !== '' ? (
              <div className="relative cursor-default select-none py-2 pl-3 pr-9 text-gray-700 dark:text-gray-300">
                No resources found.
              </div>
            ) : (
              filteredResources.map((resource) => (
                <Combobox.Option
                  key={resource.arn}
                  value={resource}
                  className={({ active }) =>
                    `relative cursor-default select-none py-2 pl-3 pr-9 ${
                      active ? 'bg-blue-600 text-white' : 'text-gray-900 dark:text-gray-200'
                    }`
                  }
                >
                  {({ active, selected }) => (
                    <>
                      <div className="flex items-center">
                        {showIcons && (
                          <span className="mr-2">
                            {getServiceIcon(resource.type)}
                          </span>
                        )}
                        <span className={`block truncate ${selected ? 'font-semibold' : ''}`}>
                          {resource.name}
                        </span>
                        <span className="ml-2 text-xs text-gray-500 dark:text-gray-400 truncate">
                          {resource.type}
                        </span>
                      </div>

                      {selected && (
                        <span
                          className={`absolute inset-y-0 right-0 flex items-center pr-4 ${
                            active ? 'text-white' : 'text-blue-600 dark:text-blue-400'
                          }`}
                        >
                          <CheckIcon className="h-5 w-5" aria-hidden="true" />
                        </span>
                      )}
                    </>
                  )}
                </Combobox.Option>
              ))
            )}
          </Combobox.Options>
        </>
      )}
    </Combobox>
  );
};

AWSDropdown.propTypes = {
  selectedItems: PropTypes.arrayOf(
    PropTypes.shape({
      arn: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired
    })
  ).isRequired,
  onSelect: PropTypes.func.isRequired,
  serviceFilter: PropTypes.string,
  regionFilter: PropTypes.string,
  maxSelections: PropTypes.number,
  showIcons: PropTypes.bool,
  withSearch: PropTypes.bool,
  className: PropTypes.string,
};

AWSDropdown.defaultProps = {
  selectedItems: [],
  serviceFilter: '',
  regionFilter: '',
  maxSelections: 3,
  showIcons: true,
  withSearch: true,
  className: '',
};

export default AWSDropdown;