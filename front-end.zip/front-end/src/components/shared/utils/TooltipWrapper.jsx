import React, { useState, useRef, useEffect } from "react";

const TooltipWrapper = ({
  children,
  content,
  position = "top",
  delay = 200, // Delay before showing tooltip (ms)
  customClass = "",
}) => {
  const [visible, setVisible] = useState(false);
  const [tooltipStyle, setTooltipStyle] = useState({});
  const tooltipRef = useRef(null);
  const timeoutRef = useRef(null);
  
  useEffect(() => {
    return () => clearTimeout(timeoutRef.current);
  }, []);

  const showTooltip = () => {
    timeoutRef.current = setTimeout(() => {
      setVisible(true);
      updatePosition();
    }, delay);
  };

  const hideTooltip = () => {
    clearTimeout(timeoutRef.current);
    setVisible(false);
  };

  const updatePosition = () => {
    if (!tooltipRef.current) return;

    const rect = tooltipRef.current.getBoundingClientRect();
    let styles = {};

    switch (position) {
      case "top":
        styles = { bottom: "100%", left: "50%", transform: "translateX(-50%)" };
        break;
      case "bottom":
        styles = { top: "100%", left: "50%", transform: "translateX(-50%)" };
        break;
      case "left":
        styles = { right: "100%", top: "50%", transform: "translateY(-50%)" };
        break;
      case "right":
        styles = { left: "100%", top: "50%", transform: "translateY(-50%)" };
        break;
      default:
        break;
    }

    setTooltipStyle(styles);
  };

  return (
    <div className="relative flex items-center group">
      <div
        className="cursor-pointer"
        onMouseEnter={showTooltip}
        onMouseLeave={hideTooltip}
        onFocus={showTooltip}
        onBlur={hideTooltip}
      >
        {children}
      </div>

      {visible && (
        <div
          ref={tooltipRef}
          className={`absolute z-50 bg-gray-900 text-white text-sm rounded-lg py-2 px-3 shadow-lg transition-all duration-300 ease-in-out ${customClass} ${
            visible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
          style={tooltipStyle}
        >
          {typeof content === "string" ? (
            <span>{content}</span>
          ) : (
            content
          )}
          <div className="absolute w-2 h-2 bg-gray-900 transform rotate-45"></div>
        </div>
      )}
    </div>
  );
};

export default TooltipWrapper;
