import React, { useState, useEffect, useRef } from "react";
import { FiClipboard, FiCheck, FiAlertCircle } from "react-icons/fi";
import toast from "react-hot-toast";

const CopyToClipboard = ({ text, tooltip = "Copy to clipboard", className = "", showToast = true }) => {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const buttonRef = useRef(null);

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2500); // Reset after 2.5s
      return () => clearTimeout(timer);
    }
  }, [copied]);

  const handleCopy = async () => {
    try {
      if (!navigator.clipboard) throw new Error("Clipboard API not available");

      await navigator.clipboard.writeText(text);
      setCopied(true);
      setCopyError(false);

      if (showToast) toast.success("Copied to clipboard!");
    } catch (err) {
      console.error("Copy failed:", err);
      setCopyError(true);
      if (showToast) toast.error("Failed to copy!");
    }
  };

  return (
    <div className="relative inline-flex items-center">
      <button
        ref={buttonRef}
        onClick={handleCopy}
        className={`flex items-center space-x-2 px-3 py-2 text-sm font-medium transition-all duration-300 rounded-md focus:ring-2 
                    ${copied ? "bg-green-500 text-white" : "bg-gray-200 hover:bg-gray-300"} 
                    ${copyError ? "bg-red-500 text-white" : ""} ${className}`}
        onKeyDown={(e) => e.key === "Enter" && handleCopy()} // Keyboard support
        aria-label={copied ? "Copied!" : "Copy to clipboard"}
      >
        {copied ? <FiCheck className="text-white" /> : copyError ? <FiAlertCircle className="text-white" /> : <FiClipboard className="text-gray-700" />}
        <span>{copied ? "Copied!" : copyError ? "Error!" : tooltip}</span>
      </button>

      {/* Floating tooltip */}
      <div className={`absolute top-full mt-1 px-2 py-1 text-xs rounded-md shadow-md transition-opacity 
                      ${copied ? "bg-green-500 text-white opacity-100" : "bg-gray-700 text-white opacity-0"}
                      ${copyError ? "bg-red-500" : ""}`}
           style={{ transition: "opacity 0.3s ease-in-out" }}>
        {copied ? "✅ Copied!" : copyError ? "❌ Failed!" : tooltip}
      </div>
    </div>
  );
};

export default CopyToClipboard;
