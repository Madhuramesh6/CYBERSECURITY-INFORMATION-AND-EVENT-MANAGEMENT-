import React from 'react';
import PropTypes from 'prop-types';
import {
  CheckCircleIcon,
  ExclamationCircleIcon,
  ClockIcon,
  ArrowPathIcon,
  ShieldExclamationIcon,
  BanIcon,
  CloudIcon
} from '@heroicons/react/24/outline';

const StatusBadge = ({
  status = 'active',
  type = 'alert',
  size = 'md',
  showIcon = true,
  showText = true,
  pulse = false,
  awsContext = false,
  className = '',
  ...props
}) => {
  // Status configuration
  const statusConfig = {
    alert: {
      active: {
        bg: 'bg-red-100 dark:bg-red-900/30',
        text: 'text-red-800 dark:text-red-200',
        icon: ShieldExclamationIcon,
        iconColor: 'text-red-500 dark:text-red-400',
        label: 'Active Alert',
        aws: 'SECURITY'
      },
      investigated: {
        bg: 'bg-yellow-100 dark:bg-yellow-900/30',
        text: 'text-yellow-800 dark:text-yellow-200',
        icon: ClockIcon,
        iconColor: 'text-yellow-500 dark:text-yellow-400',
        label: 'Under Investigation',
        aws: 'IN_PROGRESS'
      },
      resolved: {
        bg: 'bg-green-100 dark:bg-green-900/30',
        text: 'text-green-800 dark:text-green-200',
        icon: CheckCircleIcon,
        iconColor: 'text-green-500 dark:text-green-400',
        label: 'Resolved',
        aws: 'RESOLVED'
      },
      suppressed: {
        bg: 'bg-gray-100 dark:bg-gray-700',
        text: 'text-gray-800 dark:text-gray-300',
        icon: BanIcon,
        iconColor: 'text-gray-500 dark:text-gray-400',
        label: 'Suppressed',
        aws: 'SUPPRESSED'
      }
    },
    system: {
      operational: {
        bg: 'bg-green-100 dark:bg-green-900/30',
        text: 'text-green-800 dark:text-green-200',
        icon: CheckCircleIcon,
        iconColor: 'text-green-500 dark:text-green-400',
        label: 'Operational',
        aws: 'AVAILABLE'
      },
      degraded: {
        bg: 'bg-yellow-100 dark:bg-yellow-900/30',
        text: 'text-yellow-800 dark:text-yellow-200',
        icon: ExclamationCircleIcon,
        iconColor: 'text-yellow-500 dark:text-yellow-400',
        label: 'Degraded',
        aws: 'DEGRADED'
      },
      down: {
        bg: 'bg-red-100 dark:bg-red-900/30',
        text: 'text-red-800 dark:text-red-200',
        icon: ExclamationCircleIcon,
        iconColor: 'text-red-500 dark:text-red-400',
        label: 'Down',
        aws: 'UNAVAILABLE'
      },
      updating: {
        bg: 'bg-blue-100 dark:bg-blue-900/30',
        text: 'text-blue-800 dark:text-blue-200',
        icon: ArrowPathIcon,
        iconColor: 'text-blue-500 dark:text-blue-400',
        label: 'Updating',
        aws: 'UPDATING'
      }
    },
    aws: {
      normal: {
        bg: 'bg-green-100 dark:bg-green-900/30',
        text: 'text-green-800 dark:text-green-200',
        icon: CloudIcon,
        iconColor: 'text-green-500 dark:text-green-400',
        label: 'AWS Normal',
        aws: 'NORMAL'
      },
      warning: {
        bg: 'bg-aws-orange/10 dark:bg-aws-orange/20',
        text: 'text-aws-orange dark:text-aws-orange',
        icon: CloudIcon,
        iconColor: 'text-aws-orange dark:text-aws-orange',
        label: 'AWS Warning',
        aws: 'WARNING'
      },
      error: {
        bg: 'bg-red-100 dark:bg-red-900/30',
        text: 'text-red-800 dark:text-red-200',
        icon: CloudIcon,
        iconColor: 'text-red-500 dark:text-red-400',
        label: 'AWS Error',
        aws: 'ERROR'
      }
    }
  };

  // Size configuration
  const sizeConfig = {
    xs: {
      padding: 'px-2 py-0.5',
      text: 'text-xs',
      iconSize: 'h-3 w-3'
    },
    sm: {
      padding: 'px-2.5 py-1',
      text: 'text-xs',
      iconSize: 'h-3.5 w-3.5'
    },
    md: {
      padding: 'px-3 py-1',
      text: 'text-sm',
      iconSize: 'h-4 w-4'
    },
    lg: {
      padding: 'px-3 py-1.5',
      text: 'text-base',
      iconSize: 'h-5 w-5'
    }
  };

  const currentStatus = statusConfig[type]?.[status] || statusConfig.alert.active;
  const currentSize = sizeConfig[size] || sizeConfig.md;
  const Icon = currentStatus.icon;

  return (
    <span
      className={`inline-flex items-center rounded-full font-medium ${
        currentStatus.bg
      } ${
        currentStatus.text
      } ${
        currentSize.padding
      } ${
        currentSize.text
      } ${
        pulse ? 'animate-pulse' : ''
      } ${className}`}
      {...props}
    >
      {showIcon && (
        <Icon
          className={`${currentStatus.iconColor} ${currentSize.iconSize} mr-1.5`}
          aria-hidden="true"
        />
      )}
      {showText && currentStatus.label}
      {awsContext && (
        <span className="ml-1.5 text-xs opacity-80">
          {currentStatus.aws}
        </span>
      )}
    </span>
  );
};

StatusBadge.propTypes = {
  status: PropTypes.string,
  type: PropTypes.oneOf(['alert', 'system', 'aws']),
  size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg']),
  showIcon: PropTypes.bool,
  showText: PropTypes.bool,
  pulse: PropTypes.bool,
  awsContext: PropTypes.bool,
  className: PropTypes.string,
};

StatusBadge.defaultProps = {
  status: 'active',
  type: 'alert',
  size: 'md',
  showIcon: true,
  showText: true,
  pulse: false,
  awsContext: false,
  className: '',
};

export default StatusBadge;