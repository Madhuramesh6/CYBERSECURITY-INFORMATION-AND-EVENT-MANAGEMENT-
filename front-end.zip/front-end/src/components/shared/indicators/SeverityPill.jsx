import React from 'react';
import PropTypes from 'prop-types';
import {
  ShieldExclamationIcon,
  FireIcon,
  ExclamationTriangleIcon,
  InformationCircleIcon,
  ShieldCheckIcon
} from '@heroicons/react/24/outline';

const SeverityPill = ({
  severity = 'medium',
  size = 'md',
  withIcon = true,
  pulse = false,
  awsEquivalent = false,
  className = '',
  ...props
}) => {
  // Severity configuration
  const severityConfig = {
    critical: {
      bg: 'bg-red-100 dark:bg-red-900/30',
      text: 'text-red-800 dark:text-red-200',
      icon: FireIcon,
      iconColor: 'text-red-500 dark:text-red-400',
      aws: 'HIGH',
      pulse: 'animate-pulse'
    },
    high: {
      bg: 'bg-orange-100 dark:bg-orange-900/30',
      text: 'text-orange-800 dark:text-orange-200',
      icon: ShieldExclamationIcon,
      iconColor: 'text-orange-500 dark:text-orange-400',
      aws: 'MEDIUM',
      pulse: ''
    },
    medium: {
      bg: 'bg-yellow-100 dark:bg-yellow-900/30',
      text: 'text-yellow-800 dark:text-yellow-200',
      icon: ExclamationTriangleIcon,
      iconColor: 'text-yellow-500 dark:text-yellow-400',
      aws: 'LOW',
      pulse: ''
    },
    low: {
      bg: 'bg-blue-100 dark:bg-blue-900/30',
      text: 'text-blue-800 dark:text-blue-200',
      icon: ShieldCheckIcon,
      iconColor: 'text-blue-500 dark:text-blue-400',
      aws: 'INFO',
      pulse: ''
    },
    informational: {
      bg: 'bg-gray-100 dark:bg-gray-700',
      text: 'text-gray-800 dark:text-gray-300',
      icon: InformationCircleIcon,
      iconColor: 'text-gray-500 dark:text-gray-400',
      aws: 'MINOR',
      pulse: ''
    }
  };

  // Size configuration
  const sizeConfig = {
    xs: {
      padding: 'px-2 py-0.5',
      text: 'text-xs',
      iconSize: 'h-3 w-3'
    },
    sm: {
      padding: 'px-2.5 py-1',
      text: 'text-xs',
      iconSize: 'h-3.5 w-3.5'
    },
    md: {
      padding: 'px-3 py-1',
      text: 'text-sm',
      iconSize: 'h-4 w-4'
    },
    lg: {
      padding: 'px-3 py-1.5',
      text: 'text-base',
      iconSize: 'h-5 w-5'
    }
  };

  const currentSeverity = severityConfig[severity] || severityConfig.medium;
  const currentSize = sizeConfig[size] || sizeConfig.md;
  const Icon = currentSeverity.icon;

  return (
    <span
      className={`inline-flex items-center rounded-full font-medium ${
        currentSeverity.bg
      } ${
        currentSeverity.text
      } ${
        currentSize.padding
      } ${
        currentSize.text
      } ${
        pulse ? currentSeverity.pulse : ''
      } ${className}`}
      {...props}
    >
      {withIcon && (
        <Icon
          className={`${currentSeverity.iconColor} ${currentSize.iconSize} mr-1.5`}
          aria-hidden="true"
        />
      )}
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
      {awsEquivalent && (
        <span className="ml-1.5 text-xs opacity-80">
          (AWS {currentSeverity.aws})
        </span>
      )}
    </span>
  );
};

SeverityPill.propTypes = {
  severity: PropTypes.oneOf(['critical', 'high', 'medium', 'low', 'informational']),
  size: PropTypes.oneOf(['xs', 'sm', 'md', 'lg']),
  withIcon: PropTypes.bool,
  pulse: PropTypes.bool,
  awsEquivalent: PropTypes.bool,
  className: PropTypes.string,
};

SeverityPill.defaultProps = {
  severity: 'medium',
  size: 'md',
  withIcon: true,
  pulse: false,
  awsEquivalent: false,
  className: '',
};

export default SeverityPill;