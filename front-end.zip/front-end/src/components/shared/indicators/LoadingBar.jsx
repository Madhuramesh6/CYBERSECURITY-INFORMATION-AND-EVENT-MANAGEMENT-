import React from 'react';
import PropTypes from 'prop-types';
import { 
  ArrowPathIcon,
  CloudIcon,
  ShieldCheckIcon,
  ServerIcon
} from '@heroicons/react/24/outline';

const LoadingBar = ({
  progress = 0,
  status = 'loading',
  service = 'generic',
  message = '',
  speed = 'normal',
  showIcon = true,
  showPercentage = true,
  className = '',
  ...props
}) => {
  // Service-specific configurations
  const serviceConfig = {
    generic: {
      icon: ArrowPathIcon,
      color: 'bg-blue-500',
      text: 'Loading data...'
    },
    cloudwatch: {
      icon: CloudIcon,
      color: 'bg-aws-orange',
      text: 'Querying CloudWatch...'
    },
    guardduty: {
      icon: ShieldCheckIcon,
      color: 'bg-green-500',
      text: 'Analyzing threats...'
    },
    ec2: {
      icon: ServerIcon,
      color: 'bg-purple-500',
      text: 'Fetching instances...'
    }
  };

  const currentService = serviceConfig[service] || serviceConfig.generic;
  const Icon = currentService.icon;
  const animationSpeed = speed === 'fast' ? '1s' : speed === 'slow' ? '3s' : '2s';

  // Status handling
  const getStatusText = () => {
    if (message) return message;
    if (status === 'error') return 'Failed to load data';
    if (status === 'success') return 'Complete!';
    return currentService.text;
  };

  return (
    <div 
      className={`w-full bg-gray-100 dark:bg-gray-700 rounded-md overflow-hidden ${className}`}
      {...props}
    >
      {/* Progress bar container */}
      <div className="relative h-2 w-full bg-gray-200 dark:bg-gray-600">
        {/* Animated progress bar */}
        <div
          className={`h-full ${currentService.color} transition-all duration-300 ease-out`}
          style={{
            width: `${status === 'loading' ? Math.min(progress, 100) : 100}%`,
            backgroundColor: status === 'error' ? 'bg-red-500' : status === 'success' ? 'bg-green-500' : currentService.color
          }}
        >
          {/* Animation element */}
          {status === 'loading' && (
            <div 
              className="absolute top-0 left-0 h-full w-1/4 bg-white bg-opacity-50"
              style={{
                animation: `loadingShimmer ${animationSpeed} infinite`,
                transform: 'skewX(-20deg)'
              }}
            />
          )}
        </div>
      </div>

      {/* Status information */}
      <div className="mt-2 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {showIcon && (
            <Icon className={`h-4 w-4 ${
              status === 'error' ? 'text-red-500' : 
              status === 'success' ? 'text-green-500' : 
              'text-gray-500 dark:text-gray-400'
            }`} />
          )}
          <span className={`text-xs ${
            status === 'error' ? 'text-red-600 dark:text-red-400' : 
            status === 'success' ? 'text-green-600 dark:text-green-400' : 
            'text-gray-600 dark:text-gray-300'
          }`}>
            {getStatusText()}
          </span>
        </div>

        {showPercentage && status === 'loading' && (
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
            {Math.round(progress)}%
          </span>
        )}
      </div>

      {/* CSS for animation */}
      <style jsx>{`
        @keyframes loadingShimmer {
          0% { left: -25%; }
          100% { left: 125%; }
        }
      `}</style>
    </div>
  );
};

LoadingBar.propTypes = {
  progress: PropTypes.number,
  status: PropTypes.oneOf(['loading', 'success', 'error']),
  service: PropTypes.oneOf(['generic', 'cloudwatch', 'guardduty', 'ec2']),
  message: PropTypes.string,
  speed: PropTypes.oneOf(['slow', 'normal', 'fast']),
  showIcon: PropTypes.bool,
  showPercentage: PropTypes.bool,
  className: PropTypes.string,
};

LoadingBar.defaultProps = {
  progress: 0,
  status: 'loading',
  service: 'generic',
  message: '',
  speed: 'normal',
  showIcon: true,
  showPercentage: true,
  className: '',
};

export default LoadingBar;