// src/pages/dashboard/RecentAlerts.jsx
import React from 'react';

const RecentAlerts = () => {
    const alerts = [
        { id: 1, type: 'High', message: 'Unauthorized access detected' },
        { id: 2, type: 'Medium', message: 'Multiple failed login attempts' },
        { id: 3, type: 'Low', message: 'System scan completed' }
    ];

    return (
        <div className="recent-alerts">
            <h3>Recent Alerts</h3>
            <ul>
                {alerts.map(alert => (
                    <li key={alert.id} className={alert.type.toLowerCase()}>
                        {alert.type}: {alert.message}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default RecentAlerts;
