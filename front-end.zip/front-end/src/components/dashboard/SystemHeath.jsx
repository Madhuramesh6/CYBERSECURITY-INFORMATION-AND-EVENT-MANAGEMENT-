import React from 'react';

const SystemHealth = () => {
    return (
        <div className="system-health">
            <h3>System Health</h3>
            <p>Status: <span className="status-green">Operational</span></p>
            <p>CPU Usage: 45%</p>
            <p>Memory Usage: 60%</p>
        </div>
    );
};

export default SystemHealth;
