import React from 'react';

const DashboardStats = () => {
    const stats = [
        { label: 'Total Alerts', value: 124 },
        { label: 'Active Users', value: 35 },
        { label: 'System Uptime', value: '99.9%' }
    ];

    return (
        <div className="dashboard-stats">
            {stats.map((stat, index) => (
                <div key={index} className="stat-card">
                    <h3>{stat.value}</h3>
                    <p>{stat.label}</p>
                </div>
            ))}
        </div>
    );
};

export default DashboardStats;
