import React, { useEffect, useState } from "react";
import { fetchLogs } from "../api";
import { FiActivity, FiAlertTriangle, FiCheckCircle } from "react-icons/fi";

const Dashboard = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const getLogs = async () => {
      const data = await fetchLogs();
      if (data) {
        setLogs(data);
      }
    };
    getLogs();
  }, []);

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-semibold text-gray-800 mb-4">Dashboard</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <FiActivity className="text-blue-500 text-4xl mr-4" />
          <div>
            <h2 className="text-lg text-gray-700">Total Logs</h2>
            <p className="text-2xl font-bold">150</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <FiAlertTriangle className="text-yellow-500 text-4xl mr-4" />
          <div>
            <h2 className="text-lg text-gray-700">Alerts</h2>
            <p className="text-2xl font-bold">5</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <FiCheckCircle className="text-green-500 text-4xl mr-4" />
          <div>
            <h2 className="text-lg text-gray-700">Resolved Issues</h2>
            <p className="text-2xl font-bold">30</p>
          </div>
        </div>
      </div>

      {/* Logs Section */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-3">Recent Logs</h2>
        <ul>
          {logs.slice(0, 5).map((log, index) => (
            <li key={index} className="p-3 border-b border-gray-200">
              {log.message}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
