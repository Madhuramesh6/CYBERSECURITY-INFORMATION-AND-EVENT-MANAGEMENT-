import React from 'react';

const ActiveUsers = () => {
    const users = ['Admin', 'Security Analyst', 'Network Engineer'];

    return (
        <div className="active-users">
            <h3>Active Users</h3>
            <ul>
                {users.map((user, index) => (
                    <li key={index}>{user}</li>
                ))}
            </ul>
        </div>
    );
};

export default ActiveUsers;
