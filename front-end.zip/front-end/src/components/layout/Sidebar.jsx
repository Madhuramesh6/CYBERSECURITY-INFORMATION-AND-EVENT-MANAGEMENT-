import { NavLink } from "react-router-dom";
import { FiHome, FiBell, FiFileText, FiSettings } from "react-icons/fi";

const Sidebar = () => {
  return (
    <div className="h-screen w-64 bg-gray-900 text-white p-5 flex flex-col">
      {/* Sidebar Title */}
      <h1 className="text-xl font-semibold text-center mb-6">Cloud SIEM</h1>

      {/* Navigation Links */}
      <nav className="flex flex-col gap-4">
        {[
          { to: "/dashboard", icon: <FiHome />, label: "Dashboard" },
          { to: "/alerts", icon: <FiBell />, label: "Alerts" },
          { to: "/logs", icon: <FiFileText />, label: "Logs" },
          { to: "/settings", icon: <FiSettings />, label: "Settings" },
        ].map(({ to, icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center p-3 rounded-lg transition-colors ${
                isActive ? "bg-gray-700 text-yellow-300" : "hover:bg-gray-800"
              }`
            }
          >
            <span className="mr-2 text-lg">{icon}</span> {label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;
