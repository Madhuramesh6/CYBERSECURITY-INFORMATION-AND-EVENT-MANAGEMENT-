import React from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "../Sidebar";
import Header from "./Header";
import Footer from "./Footer";
import "../../styles/MainLayout.css";

const MainLayout = () => {
  return (
<div>
  <NavLink to="/dashboard" end className="front-end\src\components\dashboard\Dashboard.jsx"> Dashboard </NavLink>
  <NavLink to="/alerts" end className="front-end\src\components\alerts\AlertsPage.jsx"> Alerts </NavLink>
  <NavLink to="/logs" end className="front-end\src\components\LogTable.jsx"> Logs </NavLink>
  <NavLink to="/settings" end className="front-end\src\pages\Settings.jsx"> Settings </NavLink>

  <div className="flex min-h-screen bg-gray-100 dark:bg-gray-900">
    {/* Sidebar (Fixed) */}
    <Sidebar />

    {/* Main Content Area */}
    <div className="flex flex-col flex-1">
      <Header />
      <main className="flex-1 p-6 overflow-auto">
        <Outlet />
      </main>
      <Footer />
    </div>
  </div>
</div>
  );
};

export default MainLayout;
