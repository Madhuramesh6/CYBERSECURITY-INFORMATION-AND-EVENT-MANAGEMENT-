import React from "react";
import { useTheme } from "../../context/ThemeContext";
import { FiSun, FiMoon } from "react-icons/fi";

const Header = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="p-4 bg-white shadow-md flex justify-between items-center">
      <h1 className="text-xl font-semibold">Cloud SIEM</h1>
      <button onClick={toggleTheme} className="p-2 bg-gray-200 rounded-full">
        {theme === "light" ? <FiMoon size={20} /> : <FiSun size={20} />}
      </button>
    </header>
  );
};

export default Header;
