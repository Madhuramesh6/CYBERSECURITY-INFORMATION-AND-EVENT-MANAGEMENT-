import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../context/ThemeContext"; // Import theme context
import { FiMenu, FiX } from "react-icons/fi"; 
import "./Navbar.css";

const Navbar = () => {
    const { theme, toggleTheme } = useTheme(); // Get theme & toggle function
    const location = useLocation(); // Get current route
    const [menuOpen, setMenuOpen] = useState(false); // Mobile menu state

    const toggleMenu = () => setMenuOpen(!menuOpen);

    return (
        <nav className={`navbar ${theme === "dark" ? "navbar-dark" : "navbar-light"}`}>
            {/* Navbar Left: Logo & Menu Button */}
            <div className="navbar-left">
                <h1 className="navbar-logo">Cloud SIEM</h1>
                <button className="menu-btn md:hidden" onClick={toggleMenu}>
                    {menuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
                </button>
            </div>

            {/* Navbar Links */}
            <ul className={`nav-links ${menuOpen ? "open" : ""}`}>
                {["dashboard", "alerts", "logs", "rules"].map((route) => (
                    <li key={route}>
                        <Link 
                            to={`/${route}`} 
                            className={location.pathname === `/${route}` ? "active" : ""}
                            onClick={() => setMenuOpen(false)} // Close menu on click
                        >
                            {route.charAt(0).toUpperCase() + route.slice(1)}
                        </Link>
                    </li>
                ))}
                <li>
                    <button className="theme-toggle" onClick={toggleTheme}>
                        {theme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode"}
                    </button>
                </li>
                <li>
                    <Link to="/" className="logout-btn">Logout</Link>
                </li>
            </ul>
        </nav>
    );
};

export default Navbar;
