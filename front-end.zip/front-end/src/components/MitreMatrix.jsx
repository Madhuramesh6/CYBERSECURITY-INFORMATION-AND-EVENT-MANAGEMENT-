import attackPatterns from '../data/attack-patterns.json';

export default function MitreMatrix({ techniqueIds }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {techniqueIds.map(id => {
        const match = attackPatterns.objects.find(obj =>
          obj.external_references?.some(ref => ref.external_id === id)
        );

        return (
          <div key={id} className="bg-gray-900 text-white p-4 rounded-xl shadow-lg">
            <h3 className="font-semibold text-lg">
              {match?.external_references?.[0]?.external_id || id}
            </h3>
            <p className="text-sm">{match?.name}</p>
            <p className="text-xs mt-1">{match?.description?.slice(0, 80)}...</p>
          </div>
        );
      })}
    </div>
  );
}
