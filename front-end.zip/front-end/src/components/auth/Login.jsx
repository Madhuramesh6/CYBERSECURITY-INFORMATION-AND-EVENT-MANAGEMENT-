import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import "../../styles/auth.css";

const Login = () => {
    const { login, isLoading, error } = useAuth();
    const [email, setEmail] = useState(import.meta.env.VITE_ADMIN_EMAIL || "");
    const [password, setPassword] = useState(import.meta.env.VITE_ADMIN_PASSWORD || "");
    const [localError, setLocalError] = useState(null);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (isLoading) return;

        setLocalError(null);
        try {
            const user = await login(email, password);
            if (user) {
                navigate("/Dashboard", { replace: true }); // ✅ Correct path
            }
        } catch (error) {
            setLocalError(error.message || "Login failed. Please try again.");
        }
    };

    return (
        <div className="auth-container">
            <h2>Login</h2>
            {localError && <p className="error-message">{localError}</p>}
            {error && <p className="error-message">{error}</p>}
            <form onSubmit={handleSubmit}>
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <button type="submit" disabled={isLoading}>
                    {isLoading ? "Logging in..." : "Login"}
                </button>
            </form>
            <p>
                <a href="/ForgotPassword">Forgot Password?</a> {/* ✅ Fixed Route */}
            </p>
            <p>
                Don't have an account? <a href="/Register">Register</a> {/* ✅ Fixed Route */}
            </p>
        </div>
    );
};

export default Login;
