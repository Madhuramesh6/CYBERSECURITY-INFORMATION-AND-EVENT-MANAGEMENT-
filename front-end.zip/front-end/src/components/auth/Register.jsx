// src/pages/auth/Register.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/auth.css';

const Register = () => {
    const [userData, setUserData] = useState({ email: '', password: '', confirmPassword: '' });
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (userData.password === userData.confirmPassword) {
            console.log('User registered:', userData);
            navigate('/login');
        } else {
            alert('Passwords do not match!');
        }
    };

    return (
        <div className="auth-container">
            <h2>Register</h2>
            <form onSubmit={handleSubmit}>
                <input type="email" placeholder="Email" value={userData.email} onChange={(e) => setUserData({ ...userData, email: e.target.value })} required />
                <input type="password" placeholder="Password" value={userData.password} onChange={(e) => setUserData({ ...userData, password: e.target.value })} required />
                <input type="password" placeholder="Confirm Password" value={userData.confirmPassword} onChange={(e) => setUserData({ ...userData, confirmPassword: e.target.value })} required />
                <button type="submit">Register</button>
            </form>
            <p>Already have an account? <a href="/login">Login</a></p>
        </div>
    );
};

export default Register;
