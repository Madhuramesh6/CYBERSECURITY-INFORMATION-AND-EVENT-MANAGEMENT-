import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";

const ProtectedRoute = () => {
    const { user, isLoading, fetchUser } = useAuth();
    const location = useLocation();
    const [isChecking, setIsChecking] = useState(true);

    useEffect(() => {
        const verifyUser = async () => {
            if (!user) {
                await fetchUser();
            }
            setIsChecking(false);
        };
        verifyUser();
    }, [fetchUser, user]);

    console.log("🔍 Checking Authentication:", { user, isLoading, isChecking });

    if (isLoading || isChecking) {
        return (
            <div className="flex justify-center items-center min-h-screen">
                <div className="animate-spin border-4 border-t-transparent border-blue-500 rounded-full w-12 h-12"></div>
                <p className="mt-4 text-gray-600 text-lg">Verifying your session...</p>
            </div>
        );
    }

    if (!user) {
        console.warn("🚨 Unauthorized! Redirecting to login...");
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    return <Outlet />;
};

export default ProtectedRoute;
