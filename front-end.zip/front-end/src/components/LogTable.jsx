import React from 'react';
import '../styles/LogTable.css';

const LogTable = ({ logs }) => {
    return (
        <div className="log-table">
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Source</th>
                        <th>Message</th>
                        <th>Severity</th>
                    </tr>
                </thead>
                <tbody>
                    {logs.map((log, index) => (
                        <tr key={index} className={log.severity.toLowerCase()}>
                            <td>{new Date(log.timestamp).toLocaleString()}</td>
                            <td>{log.source}</td>
                            <td>{log.message}</td>
                            <td>{log.severity}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default LogTable;