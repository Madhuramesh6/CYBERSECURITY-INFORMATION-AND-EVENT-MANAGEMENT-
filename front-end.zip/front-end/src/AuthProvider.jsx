import { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react";
import { Amplify } from "@aws-amplify/core";
import { Auth } from "@aws-amplify/auth";
import awsConfig from "../aws-exports";
import { useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";

// ✅ Securely configure Amplify
try {
    if (!awsConfig?.Auth?.userPoolId) {
        throw new Error("Invalid AWS Cognito configuration");
    }
    Amplify.configure({
        ...awsConfig,
        Auth: {
            ...awsConfig.Auth,
            cookieStorage: {
                domain: window.location.hostname,
                secure: window.location.protocol === "https:",
                path: "/",
                expires: 7, // 7 days
                sameSite: "strict",
            },
        },
    });
} catch (configError) {
    console.error("❌ Amplify config failed:", configError);
    throw configError;
}

// ✅ Create Authentication Context
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [authState, setAuthState] = useState({
        user: null,
        isLoading: false,
        error: null,
        sessionId: null,
    });

    const navigate = useNavigate();
    const sessionId = useMemo(() => uuidv4(), []);

    // ✅ Fetch authenticated user
    const fetchUser = useCallback(async () => {
        console.log("🔍 Fetching user...");
        setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

        try {
            const currentUser = await Auth.currentAuthenticatedUser();
            const session = await Auth.currentSession();

            if (!currentUser || !session || !session.isValid()) {
                throw new Error("No active session or user is not authenticated");
            }

            const token = session.getIdToken().getJwtToken();
            const payload = session.getIdToken().decodePayload();

            const newUser = {
                username: currentUser.username,
                email: currentUser.attributes?.email || "N/A",
                groups: payload["cognito:groups"] || [],
                token,
                tokenExpiration: payload.exp,
            };

            console.log("✅ User authenticated:", newUser);

            setAuthState({
                user: newUser,
                isLoading: false,
                error: null,
                sessionId,
            });

            // Save user to localStorage
            localStorage.setItem("siem_user", JSON.stringify(newUser));

            return newUser;
        } catch (error) {
            console.warn("⚠️ Auth error:", error.message || error);
            setAuthState({
                user: null,
                isLoading: false,
                error: error.message,
                sessionId,
            });
            return null;
        }
    }, [sessionId]);

    // ✅ Secure Login Function
    const handleLogin = async (email, password) => {
        if (authState.isLoading) {
            console.warn("⚠️ Login attempt blocked: A sign-in process is already in progress.");
            return;
        }

        console.log("🔑 Logging in...");

        const loginEmail = email || process.env.REACT_APP_ADMIN_EMAIL;
        const loginPassword = password || process.env.REACT_APP_ADMIN_PASSWORD;

        if (!loginEmail || !loginPassword) {
            console.error("❌ Missing email or password!");
            return;
        }

        setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

        try {
            await Auth.signIn(loginEmail, loginPassword);
            const updatedUser = await fetchUser();
            navigate("/dashboard", { replace: true });
            return updatedUser;
        } catch (error) {
            console.error("❌ Login failed:", error);
            setAuthState(prev => ({
                ...prev,
                isLoading: false,
                error: error.message || "Login failed",
            }));
        }
    };

    // ✅ Secure Logout
    const handleLogout = async () => {
        console.log("🚪 Logging out...");
        try {
            await Auth.signOut();
            localStorage.removeItem("siem_user");
            setAuthState({
                user: null,
                isLoading: false,
                error: null,
                sessionId,
            });
            navigate("/login", { replace: true });
        } catch (error) {
            console.error("❌ Logout error:", error);
            setAuthState(prev => ({
                ...prev,
                error: error.message,
            }));
        }
    };

    // ✅ Auto-login using localStorage/session
    useEffect(() => {
        const autoLogin = async () => {
            if (authState.isLoading) return;

            const storedUser = localStorage.getItem("siem_user");

            if (storedUser) {
                console.log("🛠 Restoring session from local storage...");
                setAuthState(prev => ({
                    ...prev,
                    user: JSON.parse(storedUser),
                    isLoading: false,
                }));
            } else {
                console.log("🔑 Checking if user is already authenticated...");
                try {
                    const currentUser = await Auth.currentAuthenticatedUser();
                    if (currentUser) {
                        console.log("✅ User already logged in:", currentUser);
                        await fetchUser();
                    }
                } catch (error) {
                    console.warn("❌ No active session found:", error);
                }
            }
        };

        autoLogin();
    }, []);

    // ✅ Auto-refresh token before expiration
    useEffect(() => {
        if (!authState.user?.tokenExpiration) return;
        const expiresInMs = authState.user.tokenExpiration * 1000 - Date.now() - 60000;
        if (expiresInMs <= 0) return;

        console.log(`🔄 Refreshing token in ${expiresInMs / 1000} seconds`);

        const timer = setTimeout(() => {
            fetchUser().catch(error => console.error("❌ Token refresh failed:", error));
        }, expiresInMs);

        return () => clearTimeout(timer);
    }, [authState.user, fetchUser]);

    const contextValue = useMemo(
        () => ({
            user: authState.user,
            isLoading: authState.isLoading,
            error: authState.error,
            sessionId: authState.sessionId,
            login: handleLogin,
            logout: handleLogout,
            refreshAuth: fetchUser,
        }),
        [authState, handleLogin, handleLogout, fetchUser]
    );

    return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
}

// ✅ Custom Hook for Authentication
export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within AuthProvider");
    }
    return context;
}
