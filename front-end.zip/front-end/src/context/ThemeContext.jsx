import  { createContext, useContext, useState, useEffect } from "react";

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
    // Function to get the initial theme
    const getInitialTheme = () => {
        if (typeof window !== "undefined") {
            const storedTheme = localStorage.getItem("theme");
            if (storedTheme) return storedTheme;
            return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
        }
        return "light";
    };

    const [theme, setTheme] = useState(getInitialTheme());

    useEffect(() => {
        // Apply theme class to <html> tag for Tailwind dark mode
        document.documentElement.classList.remove("light", "dark");
        document.documentElement.classList.add(theme);

        // Add data-theme attribute for CSS-based theme handling
        document.documentElement.setAttribute("data-theme", theme);

        // Save theme preference
        localStorage.setItem("theme", theme);
    }, [theme]);

    const toggleTheme = () => {
        setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
    };

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

// Custom hook for easy theme access
export const useTheme = () => {
    const context = useContext(ThemeContext);
    if (!context) {
        throw new Error("useTheme must be used within a ThemeProvider");
    }
    return context;
};

export default ThemeContext;
