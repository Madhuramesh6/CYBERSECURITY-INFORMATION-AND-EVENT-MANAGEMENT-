import { useState, useEffect, createContext, useContext, useCallback } from "react";
import { Auth } from "aws-amplify";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [authState, setAuthState] = useState({
        user: null,
        isLoading: true,
        error: null,
    });

    const fetchUser = useCallback(async () => {
        console.log("🔍 Fetching user session...");
        setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

        try {
            const session = await Auth.currentSession();
            const currentUser = await Auth.currentAuthenticatedUser({ bypassCache: true });

            console.log("🟢 Session:", session);
            console.log("🟢 Authenticated User:", currentUser);

            if (!session || !session.isValid()) {
                throw new Error("Session is not valid");
            }

            const token = session.getIdToken().getJwtToken();
            const payload = session.getIdToken().decodePayload();

            const newUser = {
                username: currentUser.username,
                email: currentUser.attributes?.email || "N/A",
                groups: payload["cognito:groups"] || [],
                token,
                tokenExpiration: payload.exp,
            };

            console.log("✅ User authenticated:", newUser);

            setAuthState({ user: newUser, isLoading: false, error: null });
            localStorage.setItem("siem_user", JSON.stringify(newUser));

            return newUser;
        } catch (error) {
            console.warn("⚠️ Auth error:", error.message || error);
            setAuthState({ user: null, isLoading: false, error: error.message });
            return null;
        }
    }, []);

    useEffect(() => {
        fetchUser();
    }, [fetchUser]);

    return <AuthContext.Provider value={{ ...authState, fetchUser }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
    return useContext(AuthContext);
}
