const WebSocket = require("ws");
const url = require("url");

// ✅ Use a separate port (5001) to avoid conflicts with Vite (5173)
const wss = new WebSocket.Server({ port: 5001 });

wss.on("connection", (ws, req) => {
    const params = url.parse(req.url, true).query;
    const token = params.token || "No token provided";  // ✅ Handle missing tokens

    console.log(`✅ Client connected with token: ${token}`);

    // Handle messages from clients
    ws.on("message", (message) => {
        console.log(`📩 Received: ${message}`);
        ws.send(`✅ Server Echo: ${message}`); // ✅ Echo message back
    });

    // Handle client disconnection
    ws.on("close", () => {
        console.log("❌ Client disconnected");
    });

    // ✅ Send a welcome message after connection
    ws.send("🔗 Connected to WebSocket server!");
});

console.log("✅ WebSocket server running on ws://localhost:5001");
