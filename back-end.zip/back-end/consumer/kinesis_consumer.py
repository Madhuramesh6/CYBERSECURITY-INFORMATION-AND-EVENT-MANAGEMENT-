import boto3
import json
import time
import requests

# AWS Kinesis client config
kinesis_client = boto3.client(
    'kinesis',
    region_name='eu-north-1',  
    aws_access_key_id='AKIAYS2NUORAU3EKVLVB',
    aws_secret_access_key='8leHB9bpAt54a/iSrtyllGUxiijP0N6H7NmHynxt'
)

# Stream & shard config
STREAM_NAME = 'SIEM_Project'  # 👈 your Kinesis stream name
SHARD_ID = 'shardId-000000000000'  # 👈 get this via describe_stream

# Get shard iterator
def get_shard_iterator():
    response = kinesis_client.get_shard_iterator(
        StreamName='SIEM_Project',
        ShardId='shardId-000000000000',
        ShardIteratorType='LATEST'
    )
    return response['ShardIterator']

# Consume records from Kinesis and push to your FastAPI endpoint
def consume_stream():
    shard_iterator = get_shard_iterator()

    while True:
        out = kinesis_client.get_records(ShardIterator=shard_iterator, Limit=50)

        records = out['Records']
        if records:
            for record in records:
                log_data = json.loads(record['Data'])
                print(f"Received log: {log_data}")

                # Push to your SIEM logs endpoint
                try:
                    response = requests.post("http://localhost:12440/api/logs", json=log_data)
                    print(f"Log posted: {response.status_code}")
                except Exception as e:
                    print(f"Failed to post log: {e}")

        shard_iterator = out['NextShardIterator']
        time.sleep(2)  # Wait 2 seconds before next poll

if __name__ == "__main__":
    consume_stream()
