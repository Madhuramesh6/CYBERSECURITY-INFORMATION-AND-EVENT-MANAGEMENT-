const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const bodyParser = require("body-parser");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*", // Update this in production
    methods: ["GET", "POST"]
  }
});

app.use(bodyParser.json());

io.on("connection", (socket) => {
  console.log("🟢 Client connected");

  socket.on("disconnect", () => {
    console.log("🔴 Client disconnected");
  });
});

// Broadcast route
app.post("/broadcast", (req, res) => {
  const { event, data } = req.body;
  io.emit(event, data); // 🔥 send to all clients
  res.send({ status: "ok" });
});

server.listen(4000, () => {
  console.log("WebSocket server listening on port 4000");
});
