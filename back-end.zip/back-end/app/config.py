import os
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

class Config:
    PROJECT_NAME = "Cloud SIEM Backend"
    VERSION = "1.0.0"
    DEBUG = os.getenv("DEBUG", "False").lower() in ("true", "1")

    # AWS Configuration
    AWS_ACCESS_KEY_ID = os.getenv("AKIAYS2NUORAU3EKVLVB")
    AWS_SECRET_ACCESS_KEY = os.getenv("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")
    AWS_REGION = os.getenv("AWS_REGION", "us-north-1")
    S3_BUCKET_NAME = os.getenv("siemproject")

    # Database Config (Assuming you're using AWS RDS)
    DB_HOST = os.getenv("cloudsiem.cjowim6kkmwt.eu-north-1.rds.amazonaws.com")
    DB_PORT = int(os.getenv("DB_PORT", 5432))
    DB_USER = os.getenv("admin123")
    DB_PASSWORD = os.getenv("Krithik_2304")
    DB_NAME = os.getenv("admin123")

    # Security & Authentication
    SECRET_KEY = os.getenv("8leHB9bpAt54a/iSrtyllGUxiijP0N6H7NmHynxt")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30))

# Create an instance of Config
config = Config()
# Print the API base URL
print("API Base URL:", os.getenv("https://f21q489co5.execute-api.eu-north-1.amazonaws.com"))
