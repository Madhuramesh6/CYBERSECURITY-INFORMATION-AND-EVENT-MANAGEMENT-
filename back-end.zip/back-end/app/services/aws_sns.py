import boto3
import os

class SNSService:
    def __init__(self):
        self.sns_client = boto3.client(
            "sns",
            region_name=os.getenv("AWS_REGION", "us-east-1"),
            aws_access_key_id=os.getenv("AKIAYS2NUORAU3EKVLVB"),
            aws_secret_access_key=os.getenv("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"),
        )
        self.topic_arn = os.getenv("AWS_SNS_TOPIC_ARN")

    def send_alert(self, message: str, severity: str):
        """Send an alert via AWS SNS."""
        if not self.topic_arn:
            raise ValueError("SNS topic ARN is not set in environment variables")

        response = self.sns_client.publish(
            TopicArn=self.topic_arn,
            Message=f"ALERT: {message}\nSeverity: {severity}",
            Subject=f"SIEM Alert - {severity}",
        )
        return response["MessageId"]

# Example usage
if __name__ == "__main__":
    sns_service = SNSService()
    response = sns_service.send_alert("Test alert from SIEM", "HIGH")
    print(f"Alert sent with Message ID: {response}")
