import os
import boto3
from botocore.exceptions import NoCredentialsError, ClientError

# Load environment variables
AWS_ACCESS_KEY = os.getenv("AKIAYS2NUORAU3EKVLVB")
AWS_SECRET_KEY = os.getenv("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 ")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# Initialize GuardDuty client
guardduty_client = boto3.client(
    "guardduty",
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=AWS_REGION,
)

def list_detectors():
    """Lists all GuardDuty detectors (used for threat detection)."""
    try:
        response = guardduty_client.list_detectors()
        return response.get("DetectorIds", [])
    except NoCredentialsError:
        return "Error: AWS credentials not found."
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"

def get_guardduty_findings(detector_id: str):
    """Fetches findings (security threats) from GuardDuty for a given detector."""
    try:
        response = guardduty_client.list_findings(DetectorId=detector_id, MaxResults=10)
        finding_ids = response.get("FindingIds", [])

        if not finding_ids:
            return "No findings detected."

        findings = guardduty_client.get_findings(DetectorId=detector_id, FindingIds=finding_ids)
        return findings.get("Findings", [])
    except NoCredentialsError:
        return "Error: AWS credentials not found."
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"

def enable_guardduty():
    """Enables AWS GuardDuty in the selected region."""
    try:
        response = guardduty_client.create_detector(Enable=True)
        return f"GuardDuty enabled. Detector ID: {response['DetectorId']}"
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"

def disable_guardduty(detector_id: str):
    """Disables GuardDuty by deleting a detector."""
    try:
        guardduty_client.delete_detector(DetectorId=detector_id)
        return f"GuardDuty detector {detector_id} has been deleted."
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"
