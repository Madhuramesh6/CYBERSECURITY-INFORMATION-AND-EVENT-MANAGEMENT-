# app/services/alert_generator.py

import asyncio
import random
from datetime import datetime
import json
from typing import Dict, List, Optional
from ..websockets.alerts import broadcast_alert
from ..utils.logger import get_logger

logger = get_logger(__name__)

# Alert source systems
ALERT_SOURCES = [
    "Firewall", "IDS", "EDR", "WAF", "SIEM", "CloudTrail", 
    "AzureMonitor", "GuardDuty", "SecurityHub", "IAM"
]

# Alert types by category
ALERT_TYPES = {
    "access": ["Authentication Failure", "Privilege Escalation", "Unauthorized Access", "Brute Force"],
    "network": ["Port Scan", "DDoS", "Suspicious Traffic", "Data Exfiltration", "Lateral Movement"],
    "endpoint": ["Malware Detection", "Suspicious Process", "Registry Modification"],
    "threat": ["Known IOC", "Data Leak", "Ransomware", "APT Activity"],
    "audit": ["Policy Violation", "Configuration Change", "User Creation"],
    "uba": ["Abnormal Login", "Unusual User Behavior", "Credential Sharing"]
}

# Severity levels and their weights (higher number = more common)
SEVERITIES = {
    "info": 10,
    "low": 7,
    "warning": 5,
    "critical": 2
}

async def generate_random_alert() -> Dict:
    """Generate a random but realistic security alert"""
    # Select random category and related alert type
    category = random.choice(list(ALERT_TYPES.keys()))
    alert_type = random.choice(ALERT_TYPES[category])
    
    # Select severity based on weighted distribution
    severity_items = list(SEVERITIES.items())
    severity = random.choices(
        [item[0] for item in severity_items],
        weights=[item[1] for item in severity_items],
        k=1
    )[0]
    
    # Choose source system
    source = random.choice(ALERT_SOURCES)
    
    # Generate dynamic message based on alert type
    message = generate_message(category, alert_type, severity)
    
    # Create alert object
    alert = {
        "type": "alert",
        "timestamp": datetime.now().isoformat(),
        "source": source,
        "category": category,
        "alert_type": alert_type,
        "severity": severity,
        "message": message,
        "event_id": f"EVT-{random.randint(10000, 99999)}",
        "details": {
            "source_ip": f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}",
            "destination_ip": f"10.0.{random.randint(1, 254)}.{random.randint(1, 254)}",
            "user": f"user{random.randint(1, 999)}",
            "resource": f"resource-{random.randint(100, 999)}"
        }
    }
    
    return alert

def generate_message(category: str, alert_type: str, severity: str) -> str:
    """Generate contextual alert message"""
    
    if category == "access":
        if "Authentication" in alert_type:
            return f"{severity.title()} - Failed login attempts detected for user admin from unusual location"
        elif "Privilege" in alert_type:
            return f"{severity.title()} - User attempted to escalate privileges using sudo"
        else:
            return f"{severity.title()} - Unauthorized access attempt to restricted system"
            
    elif category == "network":
        if "Scan" in alert_type:
            return f"{severity.title()} - Port scan detected from external IP"
        elif "DDoS" in alert_type:
            return f"{severity.title()} - Potential DDoS attack targeting web server"
        elif "Exfiltration" in alert_type:
            return f"{severity.title()} - Unusual data transfer to external IP detected"
        else:
            return f"{severity.title()} - Suspicious network traffic pattern detected"
    
    elif category == "endpoint":
        if "Malware" in alert_type:
            return f"{severity.title()} - Potential malware detected on endpoint"
        elif "Process" in alert_type:
            return f"{severity.title()} - Unusual process execution detected"
        else:
            return f"{severity.title()} - System registry modified by unauthorized process"
    
    elif category == "threat":
        if "IOC" in alert_type:
            return f"{severity.title()} - Match with known threat indicator detected"
        elif "Ransomware" in alert_type:
            return f"{severity.title()} - Potential ransomware activity detected"
        else:
            return f"{severity.title()} - Potential APT activity detected"
    
    elif category == "audit":
        if "Policy" in alert_type:
            return f"{severity.title()} - Security policy violation detected"
        elif "Configuration" in alert_type:
            return f"{severity.title()} - Critical system configuration changed"
        else:
            return f"{severity.title()} - New admin user created outside change window"
    
    elif category == "uba":
        if "Abnormal" in alert_type:
            return f"{severity.title()} - User logged in from unusual location"
        elif "Unusual" in alert_type:
            return f"{severity.title()} - Unusual activity pattern for user"
        else:
            return f"{severity.title()} - Potential shared credentials detected"
            
    return f"{severity.title()} - Security alert: {alert_type}"

async def alert_generator_service(interval_seconds: int = 5):
    """Service that generates random alerts at specified intervals"""
    logger.info(f"Starting alert generator service. Interval: {interval_seconds} seconds")
    
    while True:
        try:
            # Generate a random alert
            alert = await generate_random_alert()
            
            # Broadcast it to all connected clients
            await broadcast_alert(alert)
            
            logger.info(f"Generated and broadcast alert: {alert['alert_type']} ({alert['severity']})")
            
            # Wait for the specified interval
            await asyncio.sleep(interval_seconds)
        except Exception as e:
            logger.error(f"Error in alert generator: {str(e)}")
            await asyncio.sleep(interval_seconds)