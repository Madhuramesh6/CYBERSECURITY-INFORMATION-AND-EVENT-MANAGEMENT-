from typing import Dict, Optional
import re

# MITRE ATT&CK Framework Constants
MITRE_TACTICS = {
    "TA0001": {"name": "Initial Access", "phase": "early"},
    "TA0002": {"name": "Execution", "phase": "mid"},
    "TA0003": {"name": "Persistence", "phase": "mid"},
    "TA0004": {"name": "Privilege Escalation", "phase": "mid"},
    "TA0005": {"name": "Defense Evasion", "phase": "mid"},
    "TA0006": {"name": "Credential Access", "phase": "mid"},
    "TA0007": {"name": "Discovery", "phase": "mid"},
    "TA0008": {"name": "Lateral Movement", "phase": "mid"},
    "TA0009": {"name": "Collection", "phase": "late"},
    "TA0011": {"name": "Command and Control", "phase": "late"},
    "TA0010": {"name": "Exfiltration", "phase": "late"},
    "TA0040": {"name": "Impact", "phase": "late"}
}

MITRE_TECHNIQUES = {
    # AWS-specific techniques
    "T1078.004": {
        "name": "Cloud Accounts",
        "tactic": "TA0001",
        "description": "Adversaries may use stolen cloud credentials to maintain persistence",
        "aws_events": ["AssumeRole", "ConsoleLogin"]
    },
    "T1530": {
        "name": "Data from Cloud Storage",
        "tactic": "TA0009",
        "description": "Access data from cloud storage objects",
        "aws_events": ["GetObject", "ListBucket"]
    },
    "T1482": {
        "name": "Domain Trust Discovery",
        "tactic": "TA0007",
        "description": "Adversaries may attempt to gather information on domain trust relationships",
        "aws_events": ["DescribeTrusts", "ListDomains"]
    },
    # Add more techniques as needed
}

class MitreMapper:
    def __init__(self):
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Pre-compile regex patterns for performance"""
        self.iam_pattern = re.compile(r'(Create|Update|Delete)(AccessKey|User|Policy)')
        self.data_exfil_pattern = re.compile(r'(Get|List|Download)(Object|Bucket|Database)')
        self.unusual_region_pattern = re.compile(r'(ap-northeast-1|sa-east-1)')  # Uncommon for your org
        
    def map_aws_event(self, event: Dict) -> Optional[Dict]:
        """
        Maps AWS CloudTrail events to MITRE ATT&CK
        
        Args:
            event: AWS CloudTrail event dictionary
            
        Returns:
            Dict with tactic and technique info or None
        """
        event_name = event.get('eventName')
        source_ip = event.get('sourceIPAddress')
        user_agent = event.get('userAgent', '').lower()
        
        # 1. Check for direct technique matches
        for tech_id, tech in MITRE_TECHNIQUES.items():
            if event_name in tech.get('aws_events', []):
                return {
                    "technique_id": tech_id,
                    "technique_name": tech["name"],
                    "tactic_id": tech["tactic"],
                    "tactic_name": MITRE_TACTICS[tech["tactic"]]["name"],
                    "confidence": 0.9  # High confidence for direct matches
                }
        
        # 2. Pattern-based detection
        detection_result = None
        
        # IAM Changes (T1098 - Account Manipulation)
        if self.iam_pattern.match(event_name):
            detection_result = {
                "technique_id": "T1098",
                "technique_name": "Account Manipulation",
                "tactic_id": "TA0003",  # Persistence
                "tactic_name": MITRE_TACTICS["TA0003"]["name"],
                "confidence": 0.7
            }
        
        # Data Exfiltration patterns
        elif self.data_exfil_pattern.match(event_name) and event.get('requestParameters', {}).get('bucketName'):
            if self._is_unusual_data_access(event):
                detection_result = {
                    "technique_id": "T1530",
                    "technique_name": "Data from Cloud Storage",
                    "tactic_id": "TA0009",  # Collection
                    "tactic_name": MITRE_TACTICS["TA0009"]["name"],
                    "confidence": 0.8
                }
        
        # Unusual region access
        elif (event_name == "ConsoleLogin" and 
              self.unusual_region_pattern.search(event.get('awsRegion', ''))):
            detection_result = {
                "technique_id": "T1078.004",
                "technique_name": "Cloud Accounts",
                "tactic_id": "TA0001",  # Initial Access
                "tactic_name": MITRE_TACTICS["TA0001"]["name"],
                "confidence": 0.6
            }
        
        # Add more detection logic as needed...
        
        return detection_result
    
    def _is_unusual_data_access(self, event: Dict) -> bool:
        """Heuristics for suspicious data access"""
        # Example: Large data download outside business hours
        event_time = event.get('eventTime', '')
        if not event_time:
            return False
            
        hour = int(event_time[11:13])  # Extract hour from ISO timestamp
        return hour < 7 or hour > 19  # Outside 7AM-7PM

# Example usage
if __name__ == "__main__":
    mapper = MitreMapper()
    
    sample_event = {
        "eventName": "GetObject",
        "sourceIPAddress": "185.143.223.41",
        "awsRegion": "us-east-1",
        "eventTime": "2023-08-15T03:14:15Z",
        "requestParameters": {
            "bucketName": "sensitive-data-bucket"
        }
    }
    
    result = mapper.map_aws_event(sample_event)
    print(f"MITRE Mapping: {result}")