import json
import datetime

class RulesEngine:
    def __init__(self):
        # Predefined security rules (These can be fetched from DB in a real setup)
        self.rules = [
            {
                "id": 1,
                "name": "Multiple Failed Logins",
                "description": "Detects more than 5 failed login attempts within 10 minutes from the same IP.",
                "condition": {
                    "field": "event_type",
                    "value": "failed_login",
                    "count": 5,
                    "time_window": 600  # 10 minutes (in seconds)
                },
                "severity": "high"
            },
            {
                "id": 2,
                "name": "Suspicious File Upload",
                "description": "Detects if a user uploads an unusually large file (>100MB).",
                "condition": {
                    "field": "file_size",
                    "operator": ">",
                    "value": 100_000_000  # 100MB in bytes
                },
                "severity": "medium"
            }
        ]

    def evaluate_log(self, log_entry):
        """
        Evaluates a single log entry against all predefined security rules.
        """
        triggered_rules = []

        for rule in self.rules:
            condition = rule["condition"]
            field = condition["field"]

            # Rule: Check if event type matches
            if field in log_entry:
                if isinstance(condition.get("count"), int):  # Rules that track occurrences
                    triggered = self.check_event_count(log_entry, condition)
                else:
                    triggered = self.evaluate_condition(log_entry, condition)

                if triggered:
                    triggered_rules.append({
                        "rule_id": rule["id"],
                        "name": rule["name"],
                        "description": rule["description"],
                        "severity": rule["severity"],
                        "timestamp": str(datetime.datetime.utcnow())
                    })

        return triggered_rules

    def evaluate_condition(self, log_entry, condition):
        """
        Evaluates a condition against a single log entry.
        """
        field = condition["field"]
        operator = condition.get("operator", "==")
        value = condition["value"]

        if operator == "==":
            return log_entry.get(field) == value
        elif operator == ">":
            return log_entry.get(field, 0) > value
        elif operator == "<":
            return log_entry.get(field, 0) < value
        return False

    def check_event_count(self, log_entry, condition):
        """
        Simulates checking for event occurrences over time (Requires database/event storage in production).
        """
        # In a real SIEM system, this would query logs stored in a database.
        # For now, we return False (not implemented)
        return False  # Placeholder for event correlation logic

    def add_rule(self, rule):
        """
        Adds a new rule to the engine.
        """
        self.rules.append(rule)
        return f"Rule '{rule['name']}' added successfully."

    def list_rules(self):
        """
        Returns all predefined security rules.
        """
        return json.dumps(self.rules, indent=4)


# Example Usage
if __name__ == "__main__":
    engine = RulesEngine()
    
    test_log = {
        "event_type": "failed_login",
        "ip_address": "192.168.1.100",
        "timestamp": "2025-02-15T10:30:00Z"
    }

    print("Triggered Rules:", engine.evaluate_log(test_log))
