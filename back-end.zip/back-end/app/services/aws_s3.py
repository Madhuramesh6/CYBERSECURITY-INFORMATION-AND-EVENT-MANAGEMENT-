import os
import boto3
from botocore.exceptions import NoCredentialsError, ClientError

# Load environment variables
AWS_ACCESS_KEY = os.getenv("AKIAYS2NUORAU3EKVLVB")
AWS_SECRET_KEY = os.getenv("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 ")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("siemproject")

# Initialize S3 client
s3_client = boto3.client(
    "s3",
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=AWS_REGION,
)

def upload_file(file_path: str, object_name: str = None) -> str:
    """Uploads a file to S3 and returns the file URL."""
    try:
        if not object_name:
            object_name = os.path.basename(file_path)

        s3_client.upload_file(file_path, S3_BUCKET_NAME, object_name)
        file_url = f"https://{S3_BUCKET_NAME}.s3.{AWS_REGION}.amazonaws.com/{object_name}"
        return file_url

    except FileNotFoundError:
        return "Error: File not found."
    except NoCredentialsError:
        return "Error: AWS credentials not found."
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"

def download_file(object_name: str, save_path: str) -> str:
    """Downloads a file from S3 and saves it locally."""
    try:
        s3_client.download_file(S3_BUCKET_NAME, object_name, save_path)
        return f"File downloaded to {save_path}"
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"

def delete_file(object_name: str) -> str:
    """Deletes a file from S3."""
    try:
        s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=object_name)
        return f"Deleted {object_name} from S3 bucket {S3_BUCKET_NAME}"
    except ClientError as e:
        return f"Error: {e.response['Error']['Message']}"
