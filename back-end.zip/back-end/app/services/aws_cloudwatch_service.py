import time
import boto3
import os
import logging
from botocore.exceptions import BotoCoreError, NoCredentialsError

class CloudWatchService:
    def __init__(self):
        """Initialize CloudWatch client"""
        try:
            self.client = boto3.client(
                "logs",
                region_name=os.getenv("AWS_REGION", "us-east-1"),
                aws_access_key_id=os.getenv("AKIAYS2NUORAU3EKVLVB"),
                aws_secret_access_key=os.getenv("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"),
            )
            self.metric_client = boto3.client(
                "cloudwatch",
                region_name=os.getenv("AWS_REGION", "us-east-1"),
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
            )
            self.log_group = os.getenv("CLOUDWATCH_LOG_GROUP", "SIEM_Logs")
            self.log_stream = os.getenv("CLOUDWATCH_LOG_STREAM", "SIEM_Stream")
            self.ensure_log_group_exists()
            self.ensure_log_stream_exists()
        except NoCredentialsError:
            logging.error("AWS credentials not found!")
        except BotoCoreError as e:
            logging.error(f"Error initializing CloudWatch: {e}")

    def ensure_log_group_exists(self):
        """Ensure that the CloudWatch Log Group exists"""
        try:
            log_groups = self.client.describe_log_groups(logGroupNamePrefix=self.log_group)
            if not any(group["logGroupName"] == self.log_group for group in log_groups.get("logGroups", [])):
                self.client.create_log_group(logGroupName=self.log_group)
        except BotoCoreError as e:
            logging.error(f"Error ensuring log group exists: {e}")

    def ensure_log_stream_exists(self):
        """Ensure that the CloudWatch Log Stream exists"""
        try:
            log_streams = self.client.describe_log_streams(logGroupName=self.log_group, logStreamNamePrefix=self.log_stream)
            if not any(stream["logStreamName"] == self.log_stream for stream in log_streams.get("logStreams", [])):
                self.client.create_log_stream(logGroupName=self.log_group, logStreamName=self.log_stream)
        except BotoCoreError as e:
            logging.error(f"Error ensuring log stream exists: {e}")

    def log_event(self, message):
        """Send logs to CloudWatch"""
        try:
            response = self.client.put_log_events(
                logGroupName=self.log_group,
                logStreamName=self.log_stream,
                logEvents=[
                    {"timestamp": int(round(time.time() * 1000)), "message": message}
                ],
            )
            return response
        except BotoCoreError as e:
            logging.error(f"Failed to send log event: {e}")
            return None

    def create_metric(self, metric_name, value, namespace="SIEM_Metrics"):
        """Publish a metric to CloudWatch"""
        try:
            response = self.metric_client.put_metric_data(
                Namespace=namespace,
                MetricData=[
                    {
                        "MetricName": metric_name,
                        "Value": value,
                        "Unit": "Count"
                    }
                ]
            )
            return response
        except BotoCoreError as e:
            logging.error(f"Failed to create metric: {e}")
            return None

    def create_alarm(self, alarm_name, metric_name, threshold, comparison_operator="GreaterThanOrEqualToThreshold"):
        """Create a CloudWatch alarm"""
        try:
            response = self.metric_client.put_metric_alarm(
                AlarmName=alarm_name,
                MetricName=metric_name,
                Namespace="SIEM_Metrics",
                Statistic="Average",
                Period=60,
                EvaluationPeriods=1,
                Threshold=threshold,
                ComparisonOperator=comparison_operator,
                ActionsEnabled=True
            )
            return response
        except BotoCoreError as e:
            logging.error(f"Failed to create alarm: {e}")
            return None
