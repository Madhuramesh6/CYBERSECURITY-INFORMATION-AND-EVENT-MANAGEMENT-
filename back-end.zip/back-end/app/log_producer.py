import boto3
import json
import time

client = boto3.client('kinesis', region_name='eu-north-1')
stream_name = 'SIEM_Project'

def send_log(log_data):
    client.put_record(
        StreamName=stream_name,
        Data=json.dumps(log_data),
        PartitionKey="partition-1"
    )

if __name__ == "__main__":
    i = 1
    while True:
        log = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "source": "Firewall",
            "severity": "INFO",
            "message": f"Test log message #{i}"
        }
        send_log(log)
        print(f"✅ Sent: {log}")
        i += 1
        time.sleep(2)
