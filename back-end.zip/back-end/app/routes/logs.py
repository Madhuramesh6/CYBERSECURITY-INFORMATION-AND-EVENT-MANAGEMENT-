from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.utils.db import get_db
from app.models.log_model import Log
from app.schemas.log_schema import LogCreate, LogResponse
from app.utils.security import get_current_user
from typing import List
from app.models import log_model

router = APIRouter(prefix="/logs", tags=["Logs"])

@router.get("/", response_model=List[LogResponse])
def get_logs(
    log_type: str = Query(None, description="Filter by log type (INFO, WARNING, ERROR)"),
    severity: int = Query(None, description="Filter by severity level"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)  # Only authenticated users can access logs
):
    query = db.query(Log)
    
    if log_type:
        query = query.filter(Log.log_type == log_type)
    if severity:
        query = query.filter(Log.severity == severity)
    
    logs = query.order_by(Log.timestamp.desc()).all()
    return logs

@router.post("/", response_model=LogResponse)
def create_log(log_data: LogCreate, db: Session = Depends(get_db)):
    new_log = Log(
        message=log_data.message,
        log_type=log_data.log_type,
        severity=log_data.severity
    )
    
    db.add(new_log)
    db.commit()
    db.refresh(new_log)

    return new_log

@router.delete("/{log_id}")
def delete_log(log_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    log = db.query(Log).filter(Log.id == log_id).first()
    if not log:
        raise HTTPException(status_code=404, detail="Log not found")
    
    db.delete(log)
    db.commit()
    
    return {"message": "Log deleted successfully"}
