import requests
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List
import requests

from app.utils.db import get_db
from app.models.alert_model import Alert
from app.schemas.alert_schema import AlertCreate, AlertResponse
from app.utils.security import get_current_user

router = APIRouter(prefix="/alerts", tags=["Alerts"])

@router.post("/", response_model=AlertResponse)
def create_alert(alert_data: AlertCreate, db: Session = Depends(get_db)):
    new_alert = Alert(
        message=alert_data.message,
        severity=alert_data.severity,
        status=alert_data.status
    )
    db.add(new_alert)
    db.commit()
    db.refresh(new_alert)

    # 🔥 Broadcast to WebSocket server
    try:
        requests.post("ws://localhost:5173/?token=cV0cqFIgdMBy", json={
            "event": "new_alert",
            "data": {
                "id": new_alert.id,
                "message": new_alert.message,
                "severity": new_alert.severity,
                "status": new_alert.status,
                "timestamp": str(new_alert.timestamp)
            }
        })
    except Exception as e:
        print(f"WebSocket broadcast failed: {e}")

    return new_alert
