from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.utils.db import get_db
from app.models.rule_model import Rule
from app.schemas.rule_schema import RuleCreate, RuleUpdate, RuleResponse
from app.utils.security import get_current_user
from typing import List

router = APIRouter(prefix="/rules", tags=["Rules"])

@router.get("/", response_model=List[RuleResponse])
def get_rules(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    rules = db.query(Rule).all()
    return rules

@router.post("/", response_model=RuleResponse)
def create_rule(rule_data: RuleCreate, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    new_rule = Rule(
        name=rule_data.name,
        description=rule_data.description,
        condition=rule_data.condition,
        severity=rule_data.severity,
        enabled=rule_data.enabled
    )
    
    db.add(new_rule)
    db.commit()
    db.refresh(new_rule)

    return new_rule

@router.put("/{rule_id}", response_model=RuleResponse)
def update_rule(rule_id: int, rule_data: RuleUpdate, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    rule = db.query(Rule).filter(Rule.id == rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")

    rule.name = rule_data.name or rule.name
    rule.description = rule_data.description or rule.description
    rule.condition = rule_data.condition or rule.condition
    rule.severity = rule_data.severity or rule.severity
    rule.enabled = rule_data.enabled if rule_data.enabled is not None else rule.enabled
    
    db.commit()
    db.refresh(rule)

    return rule

@router.delete("/{rule_id}")
def delete_rule(rule_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    rule = db.query(Rule).filter(Rule.id == rule_id).first()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")

    db.delete(rule)
    db.commit()
    
    return {"message": "Rule deleted successfully"}
