# app/real_time_alerts.py

import asyncio
import random
from datetime import datetime
import json
from .websockets.alerts import broadcast_alert
from .utils.logger import get_logger

logger = get_logger(__name__)

# Sample alert types
ALERT_TYPES = [
    {"type": "Authentication", "severity": "critical", "source": "IAM", "category": "access"},
    {"type": "Malware Detected", "severity": "critical", "source": "Endpoint", "category": "threat"},
    {"type": "Suspicious Traffic", "severity": "warning", "source": "Firewall", "category": "network"},
    {"type": "New User Created", "severity": "info", "source": "Directory", "category": "audit"},
    {"type": "Privilege Escalation", "severity": "critical", "source": "UEBA", "category": "uba"},
    {"type": "Data Exfiltration", "severity": "warning", "source": "DLP", "category": "threat"},
    {"type": "Brute Force Attempt", "severity": "warning", "source": "WAF", "category": "access"},
]

# Generate a random alert
def generate_random_alert():
    alert_template = random.choice(ALERT_TYPES)
    
    alert = {
        **alert_template,
        "id": f"alert-{random.randint(10000, 99999)}",
        "timestamp": datetime.now().isoformat(),
        "message": f"Sample {alert_template['type']} alert detected in system",
        "details": {
            "ip": f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}",
            "user": f"user{random.randint(1, 50)}@example.com",
            "resource": f"resource-{random.randint(100, 999)}"
        }
    }
    return alert

# Background task to generate and broadcast alerts
async def generate_alerts_periodically():
    while True:
        try:
            # Wait for a random interval between 5-15 seconds
            await asyncio.sleep(random.uniform(5, 15))
            
            # Generate and broadcast a random alert
            alert = generate_random_alert()
            logger.info(f"Broadcasting alert: {alert['type']}")
            await broadcast_alert(alert)
            
        except Exception as e:
            logger.error(f"Error in alert generation: {str(e)}")
            await asyncio.sleep(5)  # Wait before retrying

# Function to start the background task
def start_alert_generator():
    asyncio.create_task(generate_alerts_periodically())