# app/websockets/alerts.py

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import asyncio
import json
import datetime
from typing import List, Dict
from ..models.alert_model import Alert
from ..utils.logger import get_logger

logger = get_logger(__name__)

router = APIRouter()

# Keep track of active connections
active_connections: List[WebSocket] = []

@router.websocket("/ws/alerts")
async def websocket_endpoint(websocket: WebSocket):
    client_id = f"{websocket.client.host}:{websocket.client.port}"
    logger.info(f"WebSocket connection attempt from {client_id}")
    
    try:
        await websocket.accept()
        active_connections.append(websocket)
        logger.info(f"WebSocket client {client_id} connected. Total connections: {len(active_connections)}")
        
        # Send a welcome message
        await websocket.send_json({"type": "connection", "status": "connected", "message": "Connected to alerts stream"})
        
        # Keep the connection alive
        while True:
            try:
                # Use a timeout for receive to prevent blocking indefinitely
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                logger.debug(f"Received message from client {client_id}: {data}")
                
                # You can respond to specific client messages here if needed
                try:
                    msg_data = json.loads(data)
                    if msg_data.get("type") == "ping":
                        await websocket.send_json({"type": "pong", "timestamp": datetime.now().isoformat()})
                except json.JSONDecodeError:
                    pass  # Not JSON data, ignore
                
            except asyncio.TimeoutError:
                # Send a heartbeat/ping to keep the connection alive
                try:
                    await websocket.send_json({"type": "ping", "status": "ok"})
                    logger.debug(f"Sent heartbeat to {client_id}")
                except Exception as e:
                    logger.warning(f"Failed to send heartbeat to {client_id}: {str(e)}")
                    raise WebSocketDisconnect()
            
    except WebSocketDisconnect:
        logger.info(f"WebSocket client {client_id} disconnected")
    except Exception as e:
        logger.error(f"WebSocket error with client {client_id}: {str(e)}")
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)
        logger.info(f"Connection with {client_id} cleaned up. Remaining connections: {len(active_connections)}")


# Function to broadcast alerts to all connected clients
async def broadcast_alert(alert_data: Dict):
    if not active_connections:
        logger.debug("No active connections to broadcast alert to")
        return
    
    # Convert the alert to a dictionary if it's an Alert object
    if isinstance(alert_data, Alert):
        alert_data = alert_data.dict()
    
    # Add a timestamp if not present
    if "timestamp" not in alert_data:
        from datetime import datetime
        alert_data["timestamp"] = datetime.now().isoformat()
    
    # Add type field if not present
    if "type" not in alert_data:
        alert_data["type"] = "alert"
    
    logger.info(f"Broadcasting alert to {len(active_connections)} clients")
    
    disconnected = []
    for connection in active_connections:
        try:
            await connection.send_json(alert_data)
        except Exception as e:
            client_id = f"{connection.client.host}:{connection.client.port}" if hasattr(connection, 'client') else "unknown"
            logger.error(f"Error sending alert to client {client_id}: {str(e)}")
            disconnected.append(connection)
    
    # Remove disconnected clients
    for conn in disconnected:
        if conn in active_connections:
            active_connections.remove(conn)
    
    if disconnected:
        logger.info(f"Removed {len(disconnected)} disconnected clients. Remaining: {len(active_connections)}")