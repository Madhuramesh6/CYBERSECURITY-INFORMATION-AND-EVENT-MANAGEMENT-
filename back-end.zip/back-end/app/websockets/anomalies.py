# app/websockets/anomalies.py

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import asyncio
import json
from typing import List, Dict
from ..utils.logger import get_logger

logger = get_logger(__name__)

# Create the router
router = APIRouter()

# List to store active connections
active_connections: List[WebSocket] = []

@router.websocket("/ws/anomalies")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    logger.info(f"WebSocket client connected to anomalies. Total connections: {len(active_connections)}")
    
    try:
        # Send a welcome message
        await websocket.send_json({"type": "connection", "status": "connected", "message": "Connected to anomalies stream"})
        
        # Keep the connection alive
        while True:
            # Wait for any message from client (optional)
            data = await websocket.receive_text()
            logger.debug(f"Received message from client: {data}")
            
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected from anomalies")
    except Exception as e:
        logger.error(f"WebSocket error in anomalies: {str(e)}")
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)


# Function to broadcast anomaly events to all connected clients
async def broadcast_anomaly(anomaly_data: Dict):
    if not active_connections:
        return
    
    # Add a timestamp if not present
    if "timestamp" not in anomaly_data:
        from datetime import datetime
        anomaly_data["timestamp"] = datetime.now().isoformat()
    
    disconnected = []
    for connection in active_connections:
        try:
            await connection.send_json(anomaly_data)
        except Exception as e:
            logger.error(f"Error sending anomaly to client: {str(e)}")
            disconnected.append(connection)
    
    # Remove disconnected clients
    for conn in disconnected:
        if conn in active_connections:
            active_connections.remove(conn)