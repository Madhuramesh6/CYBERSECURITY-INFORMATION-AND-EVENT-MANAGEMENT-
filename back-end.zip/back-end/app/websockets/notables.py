# app/websockets/notables.py

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import asyncio
import json
from typing import List, Dict
from ..utils.logger import get_logger

logger = get_logger(__name__)

# Create a router instance - this is what's missing
router = APIRouter()

# List to store active connections
active_connections: List[WebSocket] = []

@router.websocket("/ws/notables")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    logger.info(f"WebSocket client connected to notables. Total connections: {len(active_connections)}")
    
    try:
        # Send a welcome message
        await websocket.send_json({"type": "connection", "status": "connected", "message": "Connected to notables stream"})
        
        # Keep the connection alive
        while True:
            # Wait for any message from client (optional)
            data = await websocket.receive_text()
            logger.debug(f"Received message from client: {data}")
            
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected from notables")
    except Exception as e:
        logger.error(f"WebSocket error in notables: {str(e)}")
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)


# Function to broadcast notable events to all connected clients
async def broadcast_notable(notable_data: Dict):
    if not active_connections:
        return
    
    # Add a timestamp if not present
    if "timestamp" not in notable_data:
        from datetime import datetime
        notable_data["timestamp"] = datetime.now().isoformat()
    
    disconnected = []
    for connection in active_connections:
        try:
            await connection.send_json(notable_data)
        except Exception as e:
            logger.error(f"Error sending notable to client: {str(e)}")
            disconnected.append(connection)
    
    # Remove disconnected clients
    for conn in disconnected:
        if conn in active_connections:
            active_connections.remove(conn)