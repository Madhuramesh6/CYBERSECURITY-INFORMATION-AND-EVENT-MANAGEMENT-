import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Database Configuration
DATABASE_URL = os.getenv("postgresql://admin123:Krithik_2304@cloudsiem.cjowim6kkmwt.eu-north-1.rds.amazonaws.com:5432/cloud_siem")
DB_HOST = os.getenv("cloudsiem.cjowim6kkmwt.eu-north-1.rds.amazonaws.com")
DB_PORT = os.getenv("5432")
DB_USER = os.getenv("admin123")
DB_PASSWORD = os.getenv("Krithik_2304")
DB_NAME = os.getenv("cloud_siem")

# Construct the Database URL for PostgreSQL (AWS RDS Compatible)
DATABASE_URL = f"postgresql://admin123:Krithik_2304@cloudsiem.cjowim6kkmwt.eu-north-1.rds.amazonaws.com:5432/cloud_siem"

# Create SQLAlchemy Engine
engine = create_engine(DATABASE_URL, pool_size=20, max_overflow=10)

# Create Session Factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base Model for ORM
Base = declarative_base()


def get_db():
    """
    Dependency Injection for Database Session.
    
    Usage in FastAPI:
    ```
    from fastapi import Depends
    from db import get_db

    def some_route(db: Session = Depends(get_db)):
        pass
    ```
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Test Connection
if __name__ == "__main__":
    try:
        with engine.connect() as connection:
            print("✅ Database connected successfully!")
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
