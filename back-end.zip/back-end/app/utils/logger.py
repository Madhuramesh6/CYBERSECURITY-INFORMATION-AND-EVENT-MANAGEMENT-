import logging
import os
from datetime import datetime

# Log file directory (ensure it exists)
LOG_DIR = "logs"
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# Log file path
LOG_FILE = os.path.join(LOG_DIR, f"siem_{datetime.now().strftime('%Y-%m-%d')}.log")

# Create a logger
base_logger = logging.getLogger("SIEMLogger")
base_logger.setLevel(logging.DEBUG)  # Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL

# Console handler (for real-time logging in terminal)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# File handler (for persistent logs)
file_handler = logging.FileHandler(LOG_FILE)
file_handler.setLevel(logging.DEBUG)

# Formatter for structured logs
log_format = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

console_handler.setFormatter(log_format)
file_handler.setFormatter(log_format)

# Add handlers to the logger
base_logger.addHandler(console_handler)
base_logger.addHandler(file_handler)


def log_event(level, message):
    """
    Logs an event at the specified level.

    :param level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    :param message: Log message
    """
    if level == "DEBUG":
        base_logger.debug(message)
    elif level == "INFO":
        base_logger.info(message)
    elif level == "WARNING":
        base_logger.warning(message)
    elif level == "ERROR":
        base_logger.error(message)
    elif level == "CRITICAL":
        base_logger.critical(message)
    else:
        base_logger.info(f"UNKNOWN LEVEL: {message}")


# Add the get_logger function that is being imported elsewhere
def get_logger(name):
    """
    Get a configured logger with the given name.
    
    Args:
        name: The name for the logger, typically __name__ of the calling module.
        
    Returns:
        A configured logger instance.
    """
    logger = logging.getLogger(name)
    
    # Only configure if not already configured
    if not logger.handlers:
        # Set log level
        logger.setLevel(logging.DEBUG)
        
        # Create handlers if they don't exist
        c_handler = logging.StreamHandler()
        c_handler.setLevel(logging.INFO)
        
        # Create file handler if LOG_DIR exists
        f_handler = None
        if os.path.exists(LOG_DIR):
            module_log_file = os.path.join(LOG_DIR, f"{name.replace('.', '_')}_{datetime.now().strftime('%Y-%m-%d')}.log")
            f_handler = logging.FileHandler(module_log_file)
            f_handler.setLevel(logging.DEBUG)
        
        # Add formatter to handlers
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        c_handler.setFormatter(formatter)
        if f_handler:
            f_handler.setFormatter(formatter)
        
        # Add handlers to logger
        logger.addHandler(c_handler)
        if f_handler:
            logger.addHandler(f_handler)
    
    return logger


# Example usage
if __name__ == "__main__":
    log_event("INFO", "SIEM Logger initialized.")
    log_event("WARNING", "Suspicious activity detected.")
    log_event("ERROR", "Failed to connect to AWS GuardDuty.")
    log_event("DEBUG", "Debugging information...")
    
    # Test the get_logger function
    test_logger = get_logger("test.module")
    test_logger.info("Test logger initialized")