from sqlalchemy import Column, Integer, String, Boolean
from app.utils.db import Base

class Rule(Base):
    __tablename__ = "rules"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    condition = Column(String, nullable=False)
    severity = Column(Integer, nullable=False)
    enabled = Column(Boolean, default=True)
