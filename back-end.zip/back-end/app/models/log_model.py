from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.utils.db import Base

class Log(Base):
    __tablename__ = "logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    log_level = Column(String, nullable=False)  # Example: INFO, WARNING, ERROR, CRITICAL
    source = Column(String, nullable=False)  # The source of the log (e.g., "Firewall", "Application")
    message = Column(Text, nullable=False)  # The log details
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # Optional if logs are user-related

    # Relationship with User Model
    user = relationship("User", back_populates="logs")