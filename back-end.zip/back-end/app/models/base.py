from app.models.base import Base
from sqlalchemy import Column, Integer, String

class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    severity = Column(String, nullable=False)
    message = Column(String, nullable=False)
