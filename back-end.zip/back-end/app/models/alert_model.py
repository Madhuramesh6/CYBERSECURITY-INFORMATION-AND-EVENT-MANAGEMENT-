from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from app.utils.db import Base

class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    severity = Column(String, nullable=False)  # Example: LOW, MEDIUM, HIGH, CRITICAL
    source = Column(String, nullable=False)  # The component that triggered the alert (e.g., "SIEM", "Firewall")
    message = Column(Text, nullable=False)  # The alert details
    is_resolved = Column(Boolean, default=False)  # Status of the alert
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # Optional if related to a user

    # Relationship with User Model
    user = relationship("User", back_populates="alerts")

# Add this in user_model.py for the relationship:
# alerts = relationship("Alert", back_populates="user", cascade="all, delete-orphan")
