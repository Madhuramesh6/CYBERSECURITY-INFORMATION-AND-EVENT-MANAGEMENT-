from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import asyncio
from app.services.alert_generator import alert_generator_service
# Import all routers
from app.websockets.alerts import router as alerts_router
from app.websockets.notables import router as notables_router
from app.websockets.anomalies import router as anomalies_router
from app.log_collector.collector import router as collector_router
from app.log_collector.anomaly_detection import router as anomaly_router
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn")
logger.info("FastAPI server started and listening for WebSocket connections")
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:12440", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
@app.on_event("startup")
async def startup_event():
    # Start alert generator service in the background
    asyncio.create_task(alert_generator_service(interval_seconds=10))  # Generate an alert every 10 seconds
    logger.info("Alert generator service started")
@app.get("/")
def read_root():
    return {"message": "Hello from Cloud SIEM backend!"}

@app.get("/api/status")
def get_status():
    return {"status": "API is running"}

# Mount routers explicitly
app.include_router(alerts_router, prefix="/api")
app.include_router(notables_router, prefix="/api")
app.include_router(anomalies_router, prefix="/api")
app.include_router(collector_router, prefix="/api")
app.include_router(anomaly_router, prefix="/api")
