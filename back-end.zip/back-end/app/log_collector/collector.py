from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import datetime

router = APIRouter()

# Define a Log model
class LogEntry(BaseModel):
    source: str
    event: str
    severity: str
    timestamp: datetime.datetime = datetime.datetime.utcnow()

# In-memory list to store collected logs (in production, you'd send this to a DB or file)
log_storage = []

# POST endpoint to collect logs
@router.post("/collect-log")
async def collect_log(log: LogEntry):
    try:
        log_storage.append(log)
        print(f"[+] Log collected: {log}")
        return {"message": "Log collected successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# GET endpoint to retrieve collected logs (for debugging/testing)
@router.get("/logs")
async def get_logs():
    return log_storage
