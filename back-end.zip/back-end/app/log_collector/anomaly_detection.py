from fastapi import APIRouter
from app.log_collector.collector import log_storage
from pydantic import BaseModel
import datetime

router = APIRouter()

# Model for detected anomaly
class Anomaly(BaseModel):
    time: str
    event: str
    source: str
    severity: str
    reason: str

# In-memory list to store detected anomalies
anomaly_storage = []

# Simple anomaly detection logic based on log severity or patterns
@router.get("/detect-anomalies")
async def detect_anomalies():
    anomalies = []

    for log in log_storage:
        # Example detection rules
        if log.severity == "High":
            anomaly = Anomaly(
                time=log.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                event=log.event,
                source=log.source,
                severity=log.severity,
                reason="High severity event detected"
            )
            anomalies.append(anomaly)

    # Store newly detected anomalies
    anomaly_storage.extend(anomalies)

    return {"anomalies_found": anomalies, "total_detected": len(anomalies)}

# Endpoint to get stored anomalies
@router.get("/anomalies")
async def get_anomalies():
    return anomaly_storage
