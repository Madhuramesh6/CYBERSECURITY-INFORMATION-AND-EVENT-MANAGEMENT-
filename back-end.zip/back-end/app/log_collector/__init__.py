from fastapi import FastAPI
from app.routes.auth import router as auth_router
from app.models import log_model
from app.routes.alerts import router as alerts_router
from app.routes.rules import router as rules_router
from app.routes.logs import router as logs_router

app = FastAPI()

# Include API routes
app.include_router(auth_router)
app.include_router(alerts_router)
app.include_router(rules_router)
app.include_router(logs_router)

