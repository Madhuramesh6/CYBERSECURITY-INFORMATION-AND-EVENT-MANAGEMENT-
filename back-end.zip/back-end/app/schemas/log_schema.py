from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from pydantic import ConfigDict

model_config = ConfigDict(from_attributes=True)


# Schema for creating a new log entry
class LogCreate(BaseModel):
    source: str = Field(..., example="firewall")
    event_type: str = Field(..., example="intrusion_detected")
    severity: int = Field(..., ge=1, le=5, example=3)  # 1 = Low, 5 = Critical
    message: str = Field(..., example="Suspicious network activity detected")
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# Schema for retrieving log details
class LogResponse(LogCreate):
    id: int

    class Config:
        from_attributes = True  # Enables ORM compatibility


# Schema for filtering logs (e.g., in API query parameters)
class LogFilter(BaseModel):
    source: Optional[str] = None
    event_type: Optional[str] = None
    severity: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    limit: Optional[int] = 100
    offset: Optional[int] = 0   
    