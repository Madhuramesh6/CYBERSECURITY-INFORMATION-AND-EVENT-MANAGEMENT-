from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional
from pydantic import ConfigDict

model_config = ConfigDict(from_attributes=True)

# Schema for creating a new alert
class AlertCreate(BaseModel):
    source: str = Field(..., example="firewall")
    alert_type: str = Field(..., example="malware_detected")
    severity: int = Field(..., ge=1, le=5, example=4)  # 1 = Low, 5 = Critical
    description: str = Field(..., example="Potential malware detected in traffic")
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# Schema for retrieving alert details
class AlertResponse(AlertCreate):
    id: int
    status: str = Field(default="open", example="resolved")  # Possible values: open, in-progress, resolved

    class Config:
        from_attributes = True  # Enables ORM compatibility


# Schema for updating alert status
class AlertUpdate(BaseModel):
    status: str = Field(..., example="resolved")  # Update alert status


# Schema for filtering alerts (e.g., in API query parameters)
class AlertFilter(BaseModel):
    source: Optional[str] = None
    alert_type: Optional[str] = None
    severity: Optional[int] = None
    status: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
