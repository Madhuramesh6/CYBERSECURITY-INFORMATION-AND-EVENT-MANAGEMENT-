from pydantic import BaseModel
from typing import Optional
from pydantic import ConfigDict

model_config = ConfigDict(from_attributes=True)

class RuleBase(BaseModel):
    name: str
    description: Optional[str] = None
    condition: str
    severity: int
    enabled: bool

class RuleCreate(RuleBase):
    pass  # Inherits all fields from RuleBase

class RuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    condition: Optional[str] = None
    severity: Optional[int] = None
    enabled: Optional[bool] = None

class RuleResponse(RuleBase):
    id: int

    class Config:
        orm_mode = True
