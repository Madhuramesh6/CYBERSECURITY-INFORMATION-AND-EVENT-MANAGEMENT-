import pytest
from httpx import AsyncClient
from app.main import app
from app.utils.db import get_db
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models.log_model import LogEntry
from unittest.mock import patch
from app.services.aws_cloudwatch_service import CloudWatchService
from app.services.aws_s3 import S3Service  # AWS S3 Mock
import json

# Create a test database in memory
TEST_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture
def test_db():
    """Set up and tear down a mock database"""
    from app.models import Base  # Import SQLAlchemy Base model
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    yield db
    db.close()
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
async def async_client():
    """Create an async test client"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_fetch_logs_unauthorized(async_client):
    """Ensure logs cannot be accessed without authentication"""
    response = await async_client.get("/logs/")
    assert response.status_code == 401  # Unauthorized

@pytest.mark.asyncio
async def test_fetch_logs_authorized(async_client):
    """Ensure logs can be retrieved with valid authentication"""
    login_response = await async_client.post("/auth/login", json={
        "username": "admin",
        "password": "AdminPassword123!"
    })
    token = login_response.json().get("access_token")

    response = await async_client.get("/logs/", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert isinstance(response.json(), list)

@pytest.mark.asyncio
async def test_create_log_entry(async_client, test_db):
    """Test creating a log entry and storing in the mock DB"""
    login_response = await async_client.post("/auth/login", json={
        "username": "admin",
        "password": "AdminPassword123!"
    })
    token = login_response.json().get("access_token")

    response = await async_client.post("/logs/create", json={
        "log_type": "INFO",
        "message": "Test log entry",
        "source": "Test System"
    }, headers={"Authorization": f"Bearer {token}"})

    assert response.status_code == 201
    assert response.json()["message"] == "Log entry created successfully"

    # Verify log is stored in the mock database
    log_entry = test_db.query(LogEntry).first()
    assert log_entry is not None
    assert log_entry.message == "Test log entry"

@pytest.mark.asyncio
async def test_log_filtering(async_client, test_db):
    """Test filtering logs by severity level"""
    login_response = await async_client.post("/auth/login", json={
        "username": "admin",
        "password": "AdminPassword123!"
    })
    token = login_response.json().get("access_token")

    # Create multiple log entries
    log_data = [
        {"log_type": "INFO", "message": "Info log", "source": "System A"},
        {"log_type": "ERROR", "message": "Error log", "source": "System B"},
        {"log_type": "WARNING", "message": "Warning log", "source": "System C"},
    ]

    for log in log_data:
        await async_client.post("/logs/create", json=log, headers={"Authorization": f"Bearer {token}"})

    # Fetch only ERROR logs
    response = await async_client.get("/logs/?log_type=ERROR", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    logs = response.json()
    assert len(logs) == 1
    assert logs[0]["log_type"] == "ERROR"

@pytest.mark.asyncio
async def test_aws_cloudwatch_integration():
    """Test AWS CloudWatch log retrieval using a mock"""
    mock_cloudwatch = patch.object(CloudWatchService, "get_logs", return_value=[{
        "timestamp": "2025-02-15T12:00:00Z",
        "message": "CloudWatch log test entry"
    }])

    with mock_cloudwatch:
        logs = CloudWatchService.get_logs("siem-log-group")
        assert len(logs) == 1
        assert logs[0]["message"] == "CloudWatch log test entry"

@pytest.mark.asyncio
async def test_aws_s3_log_backup():
    """Test AWS S3 log backup using a mock"""
    mock_s3 = patch.object(S3Service, "upload_file", return_value="s3://siem-bucket/logs/backup.json")

    with mock_s3:
        logs_data = [
            {"timestamp": "2025-02-15T12:00:00Z", "message": "Log 1"},
            {"timestamp": "2025-02-15T12:01:00Z", "message": "Log 2"}
        ]
        json_data = json.dumps(logs_data)
        file_path = "/tmp/test_log_backup.json"

        with open(file_path, "w") as f:
            f.write(json_data)

        s3_url = S3Service.upload_file(file_path, "siem-bucket", "logs/backup.json")
        assert s3_url == "s3://siem-bucket/logs/backup.json"
