import pytest
from httpx import AsyncClient
from app.main import app
from app.utils.db import get_db 
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models.alert_model import Alert
from unittest.mock import patch
from app.services.aws_sns import SNSService  # AWS SNS Mock
import json

# Create a test database in memory
TEST_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(TEST_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture
def test_db():
    """Set up and tear down a mock database"""
    from app.models import Base  # Ensure Base is imported correctly
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    yield db
    db.close()
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def override_get_db(test_db):
    """Override the database dependency"""
    def _override():
        yield test_db
    app.dependency_overrides[get_db] = _override

@pytest.fixture
async def async_client(override_get_db):
    """Create an async test client with dependency overrides"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client

@pytest.fixture
async def auth_token(async_client):
    """Mock login and return a valid authorization token"""
    login_response = await async_client.post("/auth/login", json={
        "username": "admin",
        "password": "AdminPassword123!"
    })
    return login_response.json().get("access_token")

@pytest.mark.asyncio
async def test_fetch_alerts_unauthorized(async_client):
    """Ensure alerts cannot be accessed without authentication"""
    response = await async_client.get("/alerts/")
    assert response.status_code == 401  # Unauthorized

@pytest.mark.asyncio
async def test_fetch_alerts_authorized(async_client, auth_token):
    """Ensure alerts can be retrieved with valid authentication"""
    response = await async_client.get("/alerts/", headers={"Authorization": f"Bearer {auth_token}"})
    assert response.status_code == 200
    assert isinstance(response.json(), list)

@pytest.mark.asyncio
async def test_create_alert_entry(async_client, test_db, auth_token):
    """Test creating an alert and storing it in the mock DB"""
    response = await async_client.post("/alerts/create", json={
        "severity": "HIGH",
        "message": "Test alert triggered",
        "source": "SIEM System"
    }, headers={"Authorization": f"Bearer {auth_token}"})

    assert response.status_code == 201
    assert response.json()["message"] == "Alert created successfully"

    # Verify alert is stored in the mock database
    alert_entry = test_db.query(Alert).first()
    assert alert_entry is not None
    assert alert_entry.message == "Test alert triggered"

@pytest.mark.asyncio
async def test_alert_filtering(async_client, test_db, auth_token):
    """Test filtering alerts by severity level"""
    alert_data = [
        {"severity": "LOW", "message": "Low alert", "source": "System A"},
        {"severity": "CRITICAL", "message": "Critical alert", "source": "System B"},
        {"severity": "MEDIUM", "message": "Medium alert", "source": "System C"},
    ]

    for alert in alert_data:
        await async_client.post("/alerts/create", json=alert, headers={"Authorization": f"Bearer {auth_token}"})

    # Fetch only CRITICAL alerts
    response = await async_client.get("/alerts/?severity=CRITICAL", headers={"Authorization": f"Bearer {auth_token}"})
    assert response.status_code == 200
    alerts = response.json()
    assert len(alerts) == 1
    assert alerts[0]["severity"] == "CRITICAL"

@pytest.mark.asyncio
async def test_aws_sns_alert_notification():
    """Test AWS SNS alert notification using a mock"""
    with patch.object(SNSService, "send_alert", return_value="SNS Notification Sent"):
        sns_response = SNSService.send_alert("ALERT: High CPU Usage Detected", "CRITICAL")
        assert sns_response == "SNS Notification Sent"
