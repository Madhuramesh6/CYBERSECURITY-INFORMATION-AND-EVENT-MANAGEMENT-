import pytest
from httpx import AsyncClient
from app.main import app
from app.config import config

@pytest.mark.asyncio
async def test_register_user(async_client: AsyncClient):
    """Test user registration"""
    response = await async_client.post("/auth/register", json={
        "username": "testuser",
        "email": "testuser@example.com",
        "password": "TestPassword123!"
    })
    assert response.status_code == 201
    assert response.json()["message"] == "User registered successfully"


@pytest.mark.asyncio
async def test_login_user(async_client: AsyncClient):
    """Test user login and token retrieval"""
    response = await async_client.post("/auth/login", json={
        "username": "testuser",
        "password": "TestPassword123!"
    })
    assert response.status_code == 200
    assert "access_token" in response.json()


@pytest.mark.asyncio
async def test_protected_route_without_token(async_client: AsyncClient):
    """Test access to a protected route without authentication"""
    response = await async_client.get("/protected-route")
    assert response.status_code == 401  # Unauthorized


@pytest.mark.asyncio
async def test_protected_route_with_token(async_client: AsyncClient):
    """Test access to a protected route with a valid token"""
    login_response = await async_client.post("/auth/login", json={
        "username": "testuser",
        "password": "TestPassword123!"
    })
    token = login_response.json().get("access_token")

    response = await async_client.get("/protected-route", headers={
        "Authorization": f"Bearer {token}"
    })
    assert response.status_code == 200
